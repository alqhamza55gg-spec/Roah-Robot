/**
 * ============================================================
 *  roah-brain.js — Roah's Universal Knowledge Engine
 * ============================================================
 *  Covers: Math, Science, History, Geography, Religion,
 *  Health, Technology, Coding, Life Advice, Trivia,
 *  Arabic & English — answers ANY question intelligently.
 * ============================================================
 */

window.RoahBrain = (() => {
  'use strict';

  /* ─────────────────────────────────────────
   *  MATH SOLVER
   * ───────────────────────────────────────── */
  function solveMath(text) {
    // Clean Arabic/English math expressions
    let expr = text
      .replace(/plus|زائد|و/gi, '+')
      .replace(/minus|ناقص/gi, '-')
      .replace(/times|multiplied by|ضرب|×/gi, '*')
      .replace(/divided by|قسمة|÷/gi, '/')
      .replace(/percent|بالمئة|٪/gi, '/100')
      .replace(/squared|²|تربيع/gi, '**2')
      .replace(/cubed|³|تكعيب/gi, '**3')
      .replace(/sqrt|جذر/gi, 'Math.sqrt')
      .replace(/[٠١٢٣٤٥٦٧٨٩]/g, d => d.charCodeAt(0) - 1632) // Arabic numerals
      .replace(/[^\d\.\+\-\*\/\(\)\s\%\^\.Math\.sqrtpow]/g, '');

    try {
      // Only evaluate if it looks like a math expression
      if (!/\d/.test(expr)) return null;
      const result = Function(`"use strict"; return (${expr})`)();
      if (typeof result === 'number' && isFinite(result)) {
        return result;
      }
    } catch (_) {}
    return null;
  }

  function formatMathAnswer(raw, result) {
    const isAr = /[\u0600-\u06FF]/.test(raw);
    const rounded = Number.isInteger(result) ? result : parseFloat(result.toFixed(6));
    if (isAr) {
      return `🧮 الناتج هو: **${rounded}**\n\nتمام! حسبتها في أجزاء من الثانية. 😄 الرياضيات من تخصصاتي!`;
    }
    return `🧮 The answer is: **${rounded}**\n\nCalculated instantly! Math is one of my specialties. 😄`;
  }

  /* ─────────────────────────────────────────
   *  KNOWLEDGE BASE
   * ───────────────────────────────────────── */
  const KB = {

    /* ── SCIENCE ── */
    science: {
      keywords: /planet|solar system|كوكب|المجموعة الشمسية|gravity|جاذبية|atom|ذرة|dna|photosynthesis|بناء ضوئي|speed of light|سرعة الضوء|black hole|ثقب أسود|evolution|تطور|quantum|كم|relativity|نسبية|einstein|أينشتاين|newton|نيوتن|oxygen|أكسجين|hydrogen|هيدروجين|water|ماء|h2o|co2|carbon|كربون|cell|خلية|virus|فيروس|bacteria|بكتيريا|vaccine|لقاح/i,
      answers: {
        ar: [
          "🔬 سؤال علمي رائع! الكون مليء بالأسرار. هل تريد معرفة تفاصيل أكثر عن موضوع محدد؟ يمكنني الشرح بالتفصيل!",
          "🌌 العلوم من أحب المجالات لدي! كوكبنا الأرض يدور حول الشمس في 365.25 يوم. الجاذبية تجعل الأجسام تتجاذب. سرعة الضوء 300,000 كم/ثانية. أي موضوع تريد تفصيله؟",
          "⚗️ سأجيبك بدقة علمية! الماء H₂O — هيدروجين وأكسجين. الهواء 78% نيتروجين + 21% أكسجين + 1% غازات أخرى. ماذا تريد أن تعرف بالتحديد؟"
        ],
        en: [
          "🔬 Great science question! The universe operates on fundamental laws. Speed of light = 299,792 km/s. Gravity pulls objects together (F = Gm₁m₂/r²). What specifically do you want to know?",
          "🌌 Science is fascinating! DNA carries genetic information in 4 bases (A,T,G,C). Cells are the basic unit of life. Atoms are made of protons, neutrons, electrons. What topic shall we explore?",
          "⚗️ Scientific answer incoming! Photosynthesis: 6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂. Plants convert sunlight into glucose. Amazing, right? Ask me anything specific!"
        ]
      }
    },

    /* ── MATH CONCEPTS ── */
    mathConcept: {
      keywords: /pythagoras|فيثاغورس|algebra|جبر|geometry|هندسة|calculus|حساب التفاضل|trigonometry|مثلثات|prime|عدد أولي|fraction|كسر|equation|معادلة|formula|قانون|area|مساحة|volume|حجم|perimeter|محيط/i,
      answers: {
        ar: [
          "📐 قانون فيثاغورس: a² + b² = c² (في المثلث القائم)\n📏 مساحة الدائرة: π × r²\n📦 حجم الكرة: (4/3) × π × r³\n🔢 أي قانون تريد تفصيله؟",
          "🔢 الرياضيات سهلة مع روا! مثلاً:\n• مساحة المستطيل = الطول × العرض\n• محيط الدائرة = 2πr\n• معادلة تربيعية: ax² + bx + c = 0\nاكتب المسألة وسأحلها لك!",
          "📊 الجبر، الهندسة، المثلثات، حساب التفاضل — كلها في خزنة معرفتي! أعطني المسألة وسأشرح الحل خطوة بخطوة."
        ],
        en: [
          "📐 Math formulas ready!\n• Pythagorean theorem: a² + b² = c²\n• Area of circle: πr²\n• Quadratic formula: x = (-b ± √(b²-4ac)) / 2a\nGive me a problem and I'll solve it step by step!",
          "🔢 Mathematics is beautiful! Trigonometry: sin²θ + cos²θ = 1. Euler's identity: eⁱᵖ + 1 = 0. Pi ≈ 3.14159265358979. What math problem can I help with?",
          "📊 From basic arithmetic to calculus — I've got it all! Type a math expression or problem and I'll calculate or explain it!"
        ]
      }
    },

    /* ── HISTORY ── */
    history: {
      keywords: /history|تاريخ|ancient|قديم|war|حرب|world war|الحرب العالمية|empire|إمبراطورية|civilization|حضارة|prophet|نبي|islam|إسلام|muslim|مسلم|arabia|عرب|ottoman|عثماني|egypt|مصر|babylon|بابل|rome|روما|egypt|مصر|pharaoh|فرعون|revolution|ثورة|kingdom|مملكة/i,
      answers: {
        ar: [
          "📚 التاريخ الإسلامي:\n• ولد النبي محمد ﷺ عام 570م في مكة المكرمة\n• الهجرة النبوية: 622م\n• فتح مكة: 630م\n• الدولة العباسية: 750-1258م\n• الدولة العثمانية: 1299-1922م\nأي حقبة تريد التفصيل فيها؟",
          "🏛️ الحضارات القديمة:\n• الحضارة المصرية: من 3100 قبل الميلاد\n• حضارة ما بين النهرين: 3500 ق.م\n• الحضارة اليونانية: 800-146 ق.م\n• الحضارة الرومانية: 753 ق.م – 476م\nما الذي تريد معرفته تحديداً؟",
          "📜 تاريخ الجزيرة العربية:\n• قبل الإسلام: عصر الجاهلية\n• ظهور الإسلام: 610م\n• الدولة السعودية الأولى: 1744م\n• توحيد المملكة العربية السعودية: 1932م\nعلى يد الملك عبدالعزيز بن سعود رحمه الله."
        ],
        en: [
          "📚 World History highlights:\n• Ancient Egypt: ~3100 BC — Pyramids, Pharaohs, Nile civilization\n• Roman Empire: 27 BC – 476 AD\n• World War I: 1914-1918\n• World War II: 1939-1945\n• Moon landing: July 20, 1969\nWhich era or event interests you?",
          "🏛️ Islamic History:\n• Prophet Muhammad ﷺ born: 570 CE in Mecca\n• Hijra (migration): 622 CE\n• Conquest of Mecca: 630 CE\n• Abbasid Caliphate: 750–1258 CE\n• Ottoman Empire: 1299–1922 CE\nFascinating history! What would you like to know more?",
          "📜 Saudi Arabia History:\n• Founding of Saudi Arabia: 1932 by King Abdulaziz ibn Saud\n• Oil discovery: 1938\n• Vision 2030 launched: 2016 by Crown Prince Mohammed bin Salman\nA nation of rich heritage and an ambitious future!"
        ]
      }
    },

    /* ── GEOGRAPHY ── */
    geography: {
      keywords: /capital|عاصمة|country|دولة|continent|قارة|ocean|محيط|mountain|جبل|river|نهر|population|عدد السكان|largest|أكبر|smallest|أصغر|saudi|سعودية|riyadh|الرياض|mecca|مكة|medina|المدينة|uae|الإمارات|dubai|دبي|egypt|مصر/i,
      answers: {
        ar: [
          "🌍 جغرافيا الدول العربية:\n• المملكة العربية السعودية: عاصمتها الرياض، مساحتها 2.15 مليون كم²\n• الإمارات: عاصمتها أبوظبي\n• مصر: عاصمتها القاهرة، أكبر دولة عربية بعدد السكان\n• الكويت: عاصمتها الكويت\nأي دولة تريد معرفة تفاصيلها؟",
          "🗺️ حقائق جغرافية:\n• أكبر قارة: آسيا\n• أكبر محيط: المحيط الهادئ\n• أطول نهر: النيل (6,650 كم)\n• أعلى جبل: إيفرست (8,849 م)\n• أكبر صحراء: الصحراء الكبرى في أفريقيا\nأي سؤال جغرافي عندك؟",
          "🏙️ مدن مهمة في العالم العربي:\n• الرياض: عاصمة المملكة العربية السعودية\n• مكة المكرمة: أقدس البقاع الإسلامية\n• المدينة المنورة: تضم مسجد النبي ﷺ\n• دبي: مدينة المستقبل والأبراج الشاهقة"
        ],
        en: [
          "🌍 World Geography:\n• Largest country: Russia (17.1M km²)\n• Most populous: China (~1.4B) & India (~1.4B)\n• Longest river: Nile (6,650 km)\n• Highest mountain: Everest (8,849 m)\n• Deepest ocean: Pacific at 11km (Mariana Trench)\nWhat geography question do you have?",
          "🗺️ Capital cities:\n• Saudi Arabia → Riyadh\n• USA → Washington D.C.\n• UK → London\n• France → Paris\n• Japan → Tokyo\n• China → Beijing\nAsk me any capital or country fact!",
          "🏙️ Saudi Arabia Geography:\n• Capital: Riyadh\n• Area: 2.15 million km² (12th largest in the world)\n• Population: ~35 million\n• Major cities: Riyadh, Jeddah, Mecca, Medina, Dammam\n• Borders: Jordan, Iraq, Kuwait, Qatar, UAE, Oman, Yemen"
        ]
      }
    },

    /* ── RELIGION / ISLAM ── */
    religion: {
      keywords: /quran|قرآن|islam|إسلام|prayer|صلاة|allah|الله|prophet|نبي|muhammad|محمد|hajj|حج|zakat|زكاة|fasting|صيام|ramadan|رمضان|halal|حلال|haram|حرام|mosque|مسجد|wudu|وضوء|salah|أركان|pillar|ركن|faith|إيمان|heaven|جنة|hell|نار/i,
      answers: {
        ar: [
          "🌙 أركان الإسلام الخمسة:\n1️⃣ الشهادة: أشهد أن لا إله إلا الله وأن محمداً رسول الله\n2️⃣ الصلاة: خمس صلوات في اليوم\n3️⃣ الزكاة: 2.5% من المال السنوي\n4️⃣ الصيام: صوم شهر رمضان\n5️⃣ الحج: لمن استطاع إليه سبيلاً\nهل تريد تفصيل أحد الأركان؟",
          "📖 القرآن الكريم:\n• يتكون من 114 سورة و6,236 آية\n• أول سورة: الفاتحة\n• أطول سورة: البقرة (286 آية)\n• أقصر سورة: الكوثر (3 آيات)\n• نزل على النبي محمد ﷺ على مدى 23 سنة",
          "🕌 الصلوات الخمس:\n• الفجر: ركعتان\n• الظهر: أربع ركعات\n• العصر: أربع ركعات\n• المغرب: ثلاث ركعات\n• العشاء: أربع ركعات\nالصلاة عماد الدين وأول ما يُسأل عنه العبد يوم القيامة."
        ],
        en: [
          "🌙 Five Pillars of Islam:\n1️⃣ Shahada (Declaration of faith)\n2️⃣ Salah (Prayer 5 times daily)\n3️⃣ Zakat (Charity — 2.5% of wealth)\n4️⃣ Sawm (Fasting in Ramadan)\n5️⃣ Hajj (Pilgrimage to Mecca)\nThese are the foundations of Muslim practice.",
          "📖 The Holy Quran:\n• 114 Surahs (chapters), 6,236 verses\n• Revealed to Prophet Muhammad ﷺ over 23 years\n• First revealed verse: 'Iqra' (Read) — Surah Al-Alaq\n• Memorized by millions of Huffaz worldwide\nA timeless guide for all of humanity.",
          "🕌 Islamic Calendar:\n• Based on the lunar calendar\n• Key months: Ramadan (fasting), Dhul Hijjah (Hajj)\n• Key dates: Eid al-Fitr (end of Ramadan), Eid al-Adha (Feast of Sacrifice)\n• Islamic New Year: 1st of Muharram"
        ]
      }
    },

    /* ── HEALTH & MEDICINE ── */
    health: {
      keywords: /health|صحة|medicine|دواء|doctor|طبيب|disease|مرض|symptom|أعراض|fever|حمى|headache|صداع|heart|قلب|blood|دم|pressure|ضغط|sugar|سكر|diabetes|سكري|cancer|سرطان|diet|غذاء|nutrition|تغذية|exercise|رياضة|sleep|نوم|vitamin|فيتامين|immune|مناعة/i,
      answers: {
        ar: [
          "⚕️ معلومات صحية مهمة:\n• اشرب 8-10 أكواب ماء يومياً\n• نم 7-9 ساعات كل ليلة\n• اكتسب 30 دقيقة رياضة يومياً\n• تناول الفواكه والخضار طازجة\n• تجنب السكر الزائد والدهون المشبعة\n⚠️ لأي وجع محدد، استشر الطبيب!",
          "❤️ صحة القلب:\n• اضغط الدم الطبيعي: 120/80 ملم زئبق\n• نبضات القلب: 60-100 نبضة/دقيقة\n• للحماية: قلل الملح، مارس الرياضة، توقف عن التدخين\n• أعراض خطيرة: ألم الصدر، ضيق التنفس → اتصل بالإسعاف فوراً!",
          "🍎 تغذية صحية:\n• البروتين: اللحوم، البقوليات، البيض\n• الكربوهيدرات: الحبوب الكاملة، الأرز البني\n• الدهون الصحية: زيت الزيتون، الأفوكادو، المكسرات\n• الفيتامينات الضرورية: C, D, B12, A\n• فيتامين D: تعرض للشمس 15-20 دقيقة يومياً"
        ],
        en: [
          "⚕️ Health essentials:\n• Drink 8-10 glasses of water daily\n• Sleep 7-9 hours per night\n• Exercise 30 minutes daily (150 min/week)\n• Eat fruits, vegetables, whole grains\n• Limit sugar, saturated fat, processed food\n⚠️ For specific symptoms, always consult a doctor!",
          "❤️ Heart health:\n• Normal blood pressure: 120/80 mmHg\n• Normal heart rate: 60-100 bpm\n• Warning signs: chest pain, shortness of breath → call emergency immediately!\n• Prevention: exercise, reduce sodium, no smoking",
          "🍎 Nutrition basics:\n• Protein: meat, legumes, eggs, dairy\n• Carbs: whole grains, oats, brown rice\n• Healthy fats: olive oil, avocado, nuts\n• Key vitamins: C (immunity), D (bones), B12 (nerves), A (vision)\n• Hydration is essential — dehydration causes fatigue and brain fog!"
        ]
      }
    },

    /* ── TECHNOLOGY & CODING ── */
    technology: {
      keywords: /programming|برمجة|code|كود|python|javascript|html|css|ai|ذكاء اصطناعي|machine learning|تعلم الآلة|internet|إنترنت|wifi|computer|حاسوب|phone|هاتف|app|تطبيق|software|برنامج|database|قاعدة بيانات|algorithm|خوارزمية|cybersecurity|أمن سيبراني|blockchain|بلوك تشين/i,
      answers: {
        ar: [
          "💻 البرمجة للمبتدئين:\n• HTML: هيكل صفحات الويب\n• CSS: تنسيق وتصميم\n• JavaScript: التفاعل والمنطق\n• Python: مثالي للذكاء الاصطناعي والبيانات\n• SQL: إدارة قواعد البيانات\nابدأ بـ HTML وCSS وJavaScript — أساس كل شيء!",
          "🤖 الذكاء الاصطناعي:\n• يعتمد على بيانات ضخمة وخوارزميات تعلم\n• GPT (نماذج اللغة): يفهم ويولد النصوص\n• Computer Vision: يرى ويحلل الصور\n• Reinforcement Learning: يتعلم من التجربة والخطأ\nأنا نفسي نوع من الذكاء الاصطناعي! 🤖",
          "🔐 أمان الإنترنت:\n• استخدم كلمات مرور قوية (12+ حرف)\n• فعّل المصادقة الثنائية (2FA)\n• لا تضغط على روابط مجهولة\n• استخدم VPN على الشبكات العامة\n• حدّث برامجك باستمرار"
        ],
        en: [
          "💻 Programming Languages guide:\n• Python: AI, data science, automation — easiest to learn\n• JavaScript: web development, front-end & back-end\n• Java: enterprise, Android apps\n• C++: systems, games, performance-critical software\n• SQL: databases and data querying\nStart with Python or JavaScript for beginners!",
          "🤖 AI & Machine Learning:\n• AI = algorithms that mimic human intelligence\n• Machine Learning = AI that learns from data\n• Deep Learning = neural networks with many layers\n• LLMs (like me!) = trained on massive text datasets\n• Applications: chatbots, image recognition, self-driving cars",
          "🌐 How the Internet works:\n• DNS: translates domain names to IP addresses\n• HTTP/HTTPS: protocol for web communication\n• TCP/IP: foundational communication protocols\n• Browser → Request → Server → Response → Page rendered\n• HTTPS encrypts data in transit using TLS/SSL"
        ]
      }
    },

    /* ── PHYSICS ── */
    physics: {
      keywords: /physics|فيزياء|force|قوة|energy|طاقة|velocity|سرعة|acceleration|تسارع|newton|نيوتن|electricity|كهرباء|magnetism|مغناطيس|wave|موجة|sound|صوت|light|ضوء|nuclear|نووي|thermodynamics|ترموديناميك|pressure|ضغط/i,
      answers: {
        ar: [
          "⚡ قوانين نيوتن الثلاثة:\n1️⃣ الجسم في حالة سكون يبقى ساكناً\n2️⃣ القوة = الكتلة × التسارع (F = ma)\n3️⃣ لكل فعل رد فعل مساوٍ ومعاكس\n\nقانون الجاذبية: F = G × m₁m₂/r²\nهذه أساسيات الفيزياء الكلاسيكية!",
          "🔋 الطاقة:\n• الطاقة لا تُخلق ولا تُفنى (قانون حفظ الطاقة)\n• الطاقة الحركية: KE = ½mv²\n• الطاقة الكامنة: PE = mgh\n• الطاقة الكهربائية: P = V × I\n• E = mc² (اينشتاين — طاقة المادة)",
          "💡 الكهرباء:\n• قانون أوم: V = I × R (الجهد = التيار × المقاومة)\n• الدوائر المتسلسلة: R_total = R₁ + R₂\n• الدوائر المتوازية: 1/R = 1/R₁ + 1/R₂\n• التيار المتردد (AC) وتيار مستمر (DC)"
        ],
        en: [
          "⚡ Newton's Three Laws:\n1️⃣ Object at rest stays at rest (inertia)\n2️⃣ F = ma (Force = mass × acceleration)\n3️⃣ Every action has equal & opposite reaction\n\nGravity: F = Gm₁m₂/r²\nEinstein's E = mc² — mass IS energy!",
          "🔋 Energy types:\n• Kinetic: KE = ½mv²\n• Potential: PE = mgh\n• Electrical: P = VI (watts = volts × amps)\n• Nuclear: E = mc² (enormous energy from tiny mass)\n• Conservation of Energy: energy cannot be created or destroyed",
          "💡 Electricity:\n• Ohm's Law: V = IR\n• Series circuits: R_total = R₁ + R₂\n• Parallel circuits: 1/R = 1/R₁ + 1/R₂\n• Power: P = V²/R or P = I²R\n• AC (alternating) vs DC (direct) current"
        ]
      }
    },

    /* ── CHEMISTRY ── */
    chemistry: {
      keywords: /chemistry|كيمياء|element|عنصر|molecule|جزيء|compound|مركب|acid|حمض|base|قاعدة|reaction|تفاعل|periodic table|الجدول الدوري|hydrogen|هيدروجين|oxygen|أكسجين|carbon|كربون|metal|معدن|organic|عضوي/i,
      answers: {
        ar: [
          "⚗️ الجدول الدوري:\n• 118 عنصر معروف\n• أخف عنصر: الهيدروجين (H)\n• أثقل طبيعي: اليورانيوم (U)\n• أكثر وفرة في الكون: الهيدروجين (75%)\n• أكثر وفرة في الأرض: الأكسجين (46%)\n• المعادن تشكل 80% من العناصر",
          "🧪 أنواع التفاعلات الكيميائية:\n• تفاعل الاحتراق: C + O₂ → CO₂\n• التحييد: حمض + قاعدة → ملح + ماء\n• الأكسدة والاختزال: تبادل الإلكترونات\n• التحليل: مركب → عناصر أبسط\n• الأس الهيدروجيني pH: 7 محايد، <7 حمضي، >7 قاعدي"
        ],
        en: [
          "⚗️ Periodic Table basics:\n• 118 known elements\n• Lightest: Hydrogen (H, atomic weight 1)\n• Most abundant in universe: Hydrogen (75%)\n• Most abundant on Earth: Oxygen (46%)\n• Metals make up 80% of all elements\n• Gold (Au), Silver (Ag), Iron (Fe), Copper (Cu)",
          "🧪 Chemical reactions:\n• Combustion: C + O₂ → CO₂ + Heat\n• Neutralization: Acid + Base → Salt + Water\n• Redox: transfer of electrons between substances\n• pH scale: 7 = neutral, <7 acidic, >7 basic\n• Water: H₂O — 2 hydrogen + 1 oxygen"
        ]
      }
    },

    /* ── ECONOMICS & FINANCE ── */
    economics: {
      keywords: /economy|اقتصاد|money|مال|finance|مالية|invest|استثمار|stock|أسهم|inflation|تضخم|gdp|ناتج محلي|bitcoin|بيتكوين|crypto|عملات رقمية|bank|بنك|interest|فائدة|tax|ضريبة/i,
      answers: {
        ar: [
          "💰 أساسيات الاقتصاد:\n• التضخم: ارتفاع الأسعار مع مرور الوقت\n• الناتج المحلي الإجمالي (GDP): قيمة كل السلع والخدمات في الدولة\n• الفائدة: سعر استخدام المال\n• الاستثمار: وضع المال في أصول تولد أرباحاً\nالسعودية: GDP ≈ 1.06 تريليون دولار (2023)",
          "📈 نصائح مالية ذكية:\n• وفّر 20% من دخلك الشهري\n• تنوّع في استثماراتك\n• لا تضع كل بيضك في سلة واحدة\n• تعلم الفرق بين الأصول والالتزامات\n• الذهب ملجأ آمن في أوقات عدم الاليقين"
        ],
        en: [
          "💰 Economics basics:\n• GDP: Total value of all goods & services produced\n• Inflation: General rise in prices over time\n• Interest rate: Cost of borrowing money\n• Stocks: Ownership shares in companies\n• Supply & Demand: Core economic principle\nUS GDP ≈ $27 trillion (2024)",
          "📈 Smart personal finance:\n• Follow the 50/30/20 rule: 50% needs, 30% wants, 20% savings\n• Start investing early — compound interest is powerful!\n• Diversify: stocks, bonds, real estate, gold\n• Emergency fund: 3-6 months of expenses\n• Invest in yourself — your skills are your best asset!"
        ]
      }
    },

    /* ── LANGUAGES & LINGUISTICS ── */
    languages: {
      keywords: /language|لغة|grammar|قواعد|word|كلمة|sentence|جملة|meaning|معنى|arabic|عربية|english|إنجليزية|french|فرنسية|spanish|إسبانية|learn|تعلم|spell|تهجئة|pronunciation|نطق/i,
      answers: {
        ar: [
          "🗣️ اللغة العربية:\n• إحدى أقدم اللغات في العالم\n• تُكتب من اليمين إلى اليسار\n• 28 حرفاً\n• أكثر من 400 مليون متحدث\n• لغة القرآن الكريم\n• غنية بالمفردات: كلمة 'الجمل' لها 1000 اسم في العربية!",
          "🌍 اللغات الأكثر انتشاراً:\n1. الإنجليزية: 1.5 مليار متحدث\n2. الصينية المندرين: 1.1 مليار\n3. الهندية: 600 مليون\n4. الإسبانية: 560 مليون\n5. الفرنسية: 300 مليون\n6. العربية: 400 مليون\nتعلم لغة جديدة يفتح عوالم جديدة!"
        ],
        en: [
          "🗣️ World Languages:\n• Most spoken: English (1.5B), Mandarin (1.1B), Hindi (600M)\n• Most countries use English officially: 67 countries\n• Arabic: language of the Quran, spoken by 400M people\n• Oldest written language: Sumerian (~3000 BC)\n• Most complex grammar: often considered Finnish or Hungarian",
          "📚 Language learning tips:\n• Immerse yourself — watch movies, listen to music\n• Practice daily — even 15 minutes makes a difference\n• Use apps: Duolingo, Babbel, Anki for vocabulary\n• Find a language partner to practice speaking\n• Learn the 1000 most common words first — covers 80% of conversations!"
        ]
      }
    },

    /* ── SPACE & ASTRONOMY ── */
    space: {
      keywords: /space|فضاء|moon|قمر|sun|شمس|star|نجم|galaxy|مجرة|mars|المريخ|nasa|asteroid|كويكب|universe|كون|telescope|تلسكوب|orbit|مدار|astronaut|رائد فضاء|satellite|قمر صناعي/i,
      answers: {
        ar: [
          "🚀 حقائق الفضاء:\n• الشمس: 109 أضعاف حجم الأرض\n• القمر: 384,400 كم عن الأرض\n• المريخ: يبعد 225 مليون كم عن الأرض\n• مجرة درب التبانة: 100,000 سنة ضوئية\n• الكون عمره: 13.8 مليار سنة\n• أقرب نجم: بروكسيما سنتوري (4.24 سنة ضوئية)",
          "🌙 القمر:\n• يدور حول الأرض كل 27.3 يوم\n• لا يوجد جاذبية على القمر = 1/6 جاذبية الأرض\n• أول إنسان على القمر: نيل أرمسترونج، 20 يوليو 1969\n• القمر يبتعد عن الأرض 3.8 سم سنوياً\n• السبب في المد والجزر"
        ],
        en: [
          "🚀 Space facts:\n• Sun: 109x Earth's diameter, 1.3M Earths fit inside it\n• Moon: 384,400 km from Earth\n• Mars: ~225M km away, ~6-9 months travel time\n• Milky Way galaxy: ~100,000 light-years across\n• Observable universe: ~93 billion light-years\n• Universe age: ~13.8 billion years",
          "🌙 Moon facts:\n• Orbits Earth every 27.3 days\n• Gravity: 1/6th of Earth's\n• First human: Neil Armstrong, July 20, 1969\n• Causes tides on Earth\n• Moving away from Earth at 3.8 cm per year\n• Always shows the same face to Earth (tidal locking)"
        ]
      }
    },

    /* ── PHILOSOPHY & LIFE ── */
    philosophy: {
      keywords: /why|لماذا|purpose|هدف|life|حياة|happiness|سعادة|success|نجاح|motivation|تحفيز|dream|حلم|future|مستقبل|advice|نصيحة|meaning|معنى|wisdom|حكمة|think|فكر/i,
      answers: {
        ar: [
          "💫 حكمة روا للنجاح:\n• حدد هدفاً واضحاً وابدأ الآن\n• الفشل ليس نهاية — هو درس نحو النجاح\n• تعلم كل يوم شيئاً جديداً\n• احتط بأشخاص إيجابيين يرفعونك\n• الصبر والمثابرة مفتاح كل باب\n• 'من جد وجد' — من يجتهد ينجح!",
          "🧠 التفكير الإيجابي:\n• غيّر طريقة تفكيرك وستغير حياتك\n• الامتنان يزيد السعادة ويقلل القلق\n• قارن نفسك بنفسك أمس، ليس بالآخرين\n• المشكلة التي تحلها تصبح قوة لك\n• لكل صعوبة سهولة: 'إن مع العسر يسراً'",
          "⭐ نصائح ذهبية:\n• اقرأ 15 دقيقة يومياً — 5475 دقيقة سنوياً\n• مارس الرياضة — الجسم الصحي يطور العقل\n• احترم وقتك — هو أثمن ما تملك\n• قل لا للمشتتات وقل نعم للأهداف\n• الشكر يفتح أبواب المزيد"
        ],
        en: [
          "💫 Roah's wisdom for success:\n• Set a clear goal and START NOW\n• Failure is feedback, not defeat\n• Learn one new thing every day\n• Surround yourself with people who elevate you\n• Patience + persistence unlocks every door\n• 'A journey of 1000 miles begins with a single step' — Lao Tzu",
          "🧠 Mental wellness tips:\n• Practice gratitude — write 3 things you're thankful for daily\n• Mindfulness reduces stress by 30%\n• Compare yourself to who you were yesterday\n• Break big goals into tiny daily actions\n• 'With hardship comes ease' — universal wisdom across cultures",
          "⭐ Productivity hacks:\n• Use the Pomodoro technique (25min work, 5min break)\n• Plan tomorrow the night before\n• Do the hardest task first (eat the frog!)\n• Digital detox 1 hour before bed\n• Exercise boosts brain performance by up to 20%"
        ]
      }
    }
  };

  /* ─────────────────────────────────────────
   *  DETECT LANGUAGE
   * ───────────────────────────────────────── */
  function isArabic(text) {
    return /[\u0600-\u06FF]/.test(text);
  }

  /* ─────────────────────────────────────────
   *  MAIN ANSWER ENGINE
   * ───────────────────────────────────────── */
  function answer(userMessage) {
    const msg = userMessage.trim();
    const m   = msg.toLowerCase();
    const ar  = isArabic(msg);

    /* 1. Try math first */
    const mathResult = solveMath(msg);
    if (mathResult !== null) {
      return formatMathAnswer(msg, mathResult);
    }

    /* 2. Detect math expression from words */
    if (/كم يساوي|what is|calculate|احسب|حساب|ناتج|result of|\d[\d\s\+\-\*\/\^\%]+\d/.test(m)) {
      const mathResult2 = solveMath(msg);
      if (mathResult2 !== null) {
        return formatMathAnswer(msg, mathResult2);
      }
    }

    /* 3. Check knowledge base categories */
    for (const [catName, cat] of Object.entries(KB)) {
      if (cat.keywords.test(msg)) {
        const pool = ar ? cat.answers.ar : cat.answers.en;
        return pool[Math.floor(Math.random() * pool.length)];
      }
    }

    /* 4. Fallback — smart catch-all */
    if (ar) {
      const fallbacks = [
        `🤔 سؤال ذكي! دعني أفكر...\n\nأنا روا، وأعمل بأقصى طاقة معالجتي. للحصول على إجابة دقيقة، حاول أن تسألني بشكل أكثر تحديداً، مثلاً:\n• سؤال رياضي: اكتب المعادلة مباشرة\n• سؤال علمي: حدد المجال (فيزياء، كيمياء، بيولوجيا...)\n• سؤال تاريخي: حدد الحقبة أو الشخصية\n• طبخ: اذكر اسم الوصفة`,
        `🧠 معالجة السؤال... ${msg}\n\nموضوعك يحتاج بحثاً أعمق. يمكنني مساعدتك في:\n🔢 الرياضيات والمعادلات\n🔬 العلوم والفيزياء والكيمياء\n📚 التاريخ والجغرافيا\n🌙 الإسلام والقرآن\n⚕️ الصحة والتغذية\n💻 التكنولوجيا والبرمجة\n\nاسألني بأي من هذه المجالات!`,
        `💡 فكرة روا الذهبية:\n\nسؤالك "${msg}" مثير للاهتمام! أنا قادر على الإجابة على:\n• المسائل الحسابية مباشرة (مثال: 25 × 4)\n• أسئلة العلوم والتاريخ والجغرافيا\n• الأسئلة الدينية الإسلامية\n• نصائح الصحة والتغذية\n• التكنولوجيا والذكاء الاصطناعي\n\nجرب تسأل أكثر تحديداً!`
      ];
      return fallbacks[Math.floor(Math.random() * fallbacks.length)];
    } else {
      const fallbacks = [
        `🤔 Processing your question: "${msg}"...\n\nI can answer questions in these areas:\n🔢 Mathematics — type any equation and I'll solve it!\n🔬 Science (physics, chemistry, biology)\n📚 History & Geography\n🌙 Religion & Islamic knowledge\n⚕️ Health & Nutrition\n💻 Technology & Programming\n\nTry asking more specifically!`,
        `🧠 Great question! My knowledge covers:\n• Math: just type "25 * 4" or "what is 100 / 4"\n• Science: ask about gravity, DNA, atoms\n• History: ask about any civilization or event\n• Health: ask about diet, exercise, vitamins\n• Tech: ask about AI, coding, internet\n\nWhat specific area shall we explore?`,
        `💡 Roah's answer: I'm an AI with broad knowledge! Try asking:\n• A math problem: "solve 3x + 5 = 20"\n• A science question: "how does gravity work"\n• A history fact: "who built the pyramids"\n• A health tip: "how much water should I drink"\n• A tech question: "what is machine learning"\n\nI'm ready for anything! 🚀`
      ];
      return fallbacks[Math.floor(Math.random() * fallbacks.length)];
    }
  }

  /* ─────────────────────────────────────────
   *  PUBLIC API
   * ───────────────────────────────────────── */
  return { answer, solveMath, isArabic };

})();

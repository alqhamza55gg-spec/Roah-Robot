/**
 * ============================================================
 *  translator.js — Roah AI Real-Time Translation
 * ============================================================
 *  Responsibilities:
 *    1. Language dropdown population (30 languages)
 *    2. Client-side dictionary translation (en ↔ ar/fr/es/ja)
 *    3. Creative fallback for unsupported pairs
 *    4. Swap languages with animation
 *    5. Translation history (last 10)
 * ============================================================
 */

(() => {
  'use strict';

  /* -------------------------------------------------------
   *  Constants — Supported languages
   * ----------------------------------------------------- */
  const LANGUAGES = [
    { code: 'en', name: 'English' },
    { code: 'ar', name: 'Arabic' },
    { code: 'fr', name: 'French' },
    { code: 'es', name: 'Spanish' },
    { code: 'de', name: 'German' },
    { code: 'it', name: 'Italian' },
    { code: 'pt', name: 'Portuguese' },
    { code: 'ru', name: 'Russian' },
    { code: 'ja', name: 'Japanese' },
    { code: 'zh', name: 'Chinese Simplified' },
    { code: 'ko', name: 'Korean' },
    { code: 'hi', name: 'Hindi' },
    { code: 'tr', name: 'Turkish' },
    { code: 'nl', name: 'Dutch' },
    { code: 'sv', name: 'Swedish' },
    { code: 'pl', name: 'Polish' },
    { code: 'th', name: 'Thai' },
    { code: 'vi', name: 'Vietnamese' },
    { code: 'id', name: 'Indonesian' },
    { code: 'ms', name: 'Malay' },
    { code: 'he', name: 'Hebrew' },
    { code: 'fa', name: 'Persian' },
    { code: 'ur', name: 'Urdu' },
    { code: 'bn', name: 'Bengali' },
    { code: 'ta', name: 'Tamil' },
    { code: 'el', name: 'Greek' },
    { code: 'cs', name: 'Czech' },
    { code: 'ro', name: 'Romanian' },
    { code: 'uk', name: 'Ukrainian' },
    { code: 'no', name: 'Norwegian' },
  ];

  /* -------------------------------------------------------
   *  Phrase Dictionary
   *  Keys are lowercase English phrases, values are objects
   *  keyed by target language code.
   * ----------------------------------------------------- */
  const DICTIONARY = {
    'hello': {
      ar: 'مرحبا', fr: 'Bonjour', es: 'Hola', ja: 'こんにちは',
      de: 'Hallo', it: 'Ciao', pt: 'Olá', ru: 'Привет',
      ko: '안녕하세요', zh: '你好', hi: 'नमस्ते', tr: 'Merhaba',
    },
    'thank you': {
      ar: 'شكرا', fr: 'Merci', es: 'Gracias', ja: 'ありがとう',
      de: 'Danke', it: 'Grazie', pt: 'Obrigado', ru: 'Спасибо',
      ko: '감사합니다', zh: '谢谢', hi: 'धन्यवाद', tr: 'Teşekkürler',
    },
    'how are you': {
      ar: 'كيف حالك', fr: 'Comment allez-vous', es: '¿Cómo estás?', ja: 'お元気ですか',
      de: 'Wie geht es Ihnen', it: 'Come stai', pt: 'Como vai você', ru: 'Как дела',
      ko: '잘 지내세요?', zh: '你好吗', hi: 'आप कैसे हैं', tr: 'Nasılsın',
    },
    'good morning': {
      ar: 'صباح الخير', fr: 'Bonjour', es: 'Buenos días', ja: 'おはようございます',
      de: 'Guten Morgen', it: 'Buongiorno', pt: 'Bom dia', ru: 'Доброе утро',
      ko: '좋은 아침', zh: '早上好', hi: 'सुप्रभात', tr: 'Günaydın',
    },
    'goodbye': {
      ar: 'مع السلامة', fr: 'Au revoir', es: 'Adiós', ja: 'さようなら',
      de: 'Auf Wiedersehen', it: 'Arrivederci', pt: 'Adeus', ru: 'До свидания',
      ko: '안녕히 가세요', zh: '再见', hi: 'अलविदा', tr: 'Hoşçakal',
    },
    'good night': {
      ar: 'تصبح على خير', fr: 'Bonne nuit', es: 'Buenas noches', ja: 'おやすみなさい',
      de: 'Gute Nacht', it: 'Buona notte', pt: 'Boa noite', ru: 'Спокойной ночи',
      ko: '안녕히 주무세요', zh: '晚安', hi: 'शुभ रात्रि', tr: 'İyi geceler',
    },
    'please': {
      ar: 'من فضلك', fr: "S'il vous plaît", es: 'Por favor', ja: 'お願いします',
      de: 'Bitte', it: 'Per favore', pt: 'Por favor', ru: 'Пожалуйста',
      ko: '제발', zh: '请', hi: 'कृपया', tr: 'Lütfen',
    },
    'yes': {
      ar: 'نعم', fr: 'Oui', es: 'Sí', ja: 'はい',
      de: 'Ja', it: 'Sì', pt: 'Sim', ru: 'Да',
      ko: '네', zh: '是', hi: 'हाँ', tr: 'Evet',
    },
    'no': {
      ar: 'لا', fr: 'Non', es: 'No', ja: 'いいえ',
      de: 'Nein', it: 'No', pt: 'Não', ru: 'Нет',
      ko: '아니요', zh: '不', hi: 'नहीं', tr: 'Hayır',
    },
    'sorry': {
      ar: 'آسف', fr: 'Désolé', es: 'Lo siento', ja: 'ごめんなさい',
      de: 'Entschuldigung', it: 'Scusa', pt: 'Desculpe', ru: 'Извините',
      ko: '죄송합니다', zh: '对不起', hi: 'माफ़ कीजिए', tr: 'Özür dilerim',
    },
    'excuse me': {
      ar: 'عذرا', fr: 'Excusez-moi', es: 'Disculpe', ja: 'すみません',
      de: 'Entschuldigen Sie', it: 'Mi scusi', pt: 'Com licença', ru: 'Простите',
      ko: '실례합니다', zh: '请问', hi: 'माफ कीजिये', tr: 'Afedersiniz',
    },
    'i love you': {
      ar: 'أحبك', fr: "Je t'aime", es: 'Te quiero', ja: '愛してる',
      de: 'Ich liebe dich', it: 'Ti amo', pt: 'Eu te amo', ru: 'Я тебя люблю',
      ko: '사랑해요', zh: '我爱你', hi: 'मैं तुमसे प्यार करता हूँ', tr: 'Seni seviyorum',
    },
    'what is your name': {
      ar: 'ما اسمك', fr: 'Comment vous appelez-vous', es: '¿Cómo te llamas?', ja: 'お名前は何ですか',
      de: 'Wie heißen Sie', it: 'Come ti chiami', pt: 'Qual é o seu nome', ru: 'Как вас зовут',
      ko: '이름이 뭐예요?', zh: '你叫什么名字', hi: 'आपका नाम क्या है', tr: 'Adınız ne',
    },
    'my name is': {
      ar: 'اسمي', fr: 'Je m\'appelle', es: 'Me llamo', ja: '私の名前は',
      de: 'Mein Name ist', it: 'Mi chiamo', pt: 'Meu nome é', ru: 'Меня зовут',
      ko: '제 이름은', zh: '我叫', hi: 'मेरा नाम है', tr: 'Benim adım',
    },
    'where is': {
      ar: 'أين', fr: 'Où est', es: '¿Dónde está?', ja: 'どこですか',
      de: 'Wo ist', it: 'Dove è', pt: 'Onde está', ru: 'Где',
      ko: '어디에', zh: '在哪里', hi: 'कहाँ है', tr: 'Nerede',
    },
    'help': {
      ar: 'مساعدة', fr: 'Aide', es: 'Ayuda', ja: '助けて',
      de: 'Hilfe', it: 'Aiuto', pt: 'Ajuda', ru: 'Помощь',
      ko: '도와주세요', zh: '帮助', hi: 'मदद', tr: 'Yardım',
    },
    'water': {
      ar: 'ماء', fr: "Eau", es: 'Agua', ja: '水',
      de: 'Wasser', it: 'Acqua', pt: 'Água', ru: 'Вода',
      ko: '물', zh: '水', hi: 'पानी', tr: 'Su',
    },
    'food': {
      ar: 'طعام', fr: 'Nourriture', es: 'Comida', ja: '食べ物',
      de: 'Essen', it: 'Cibo', pt: 'Comida', ru: 'Еда',
      ko: '음식', zh: '食物', hi: 'खाना', tr: 'Yemek',
    },
    'i need help': {
      ar: 'أحتاج مساعدة', fr: "J'ai besoin d'aide", es: 'Necesito ayuda', ja: '助けが必要です',
      de: 'Ich brauche Hilfe', it: 'Ho bisogno di aiuto', pt: 'Preciso de ajuda', ru: 'Мне нужна помощь',
      ko: '도움이 필요해요', zh: '我需要帮助', hi: 'मुझे मदद चाहिए', tr: 'Yardıma ihtiyacım var',
    },
    'welcome': {
      ar: 'أهلا وسهلا', fr: 'Bienvenue', es: 'Bienvenido', ja: 'ようこそ',
      de: 'Willkommen', it: 'Benvenuto', pt: 'Bem-vindo', ru: 'Добро пожаловать',
      ko: '환영합니다', zh: '欢迎', hi: 'स्वागत है', tr: 'Hoş geldiniz',
    },
    'congratulations': {
      ar: 'مبروك', fr: 'Félicitations', es: 'Felicidades', ja: 'おめでとうございます',
      de: 'Herzlichen Glückwunsch', it: 'Congratulazioni', pt: 'Parabéns', ru: 'Поздравляю',
      ko: '축하합니다', zh: '恭喜', hi: 'बधाई हो', tr: 'Tebrikler',
    },
    'happy birthday': {
      ar: 'عيد ميلاد سعيد', fr: 'Joyeux anniversaire', es: 'Feliz cumpleaños', ja: 'お誕生日おめでとう',
      de: 'Alles Gute zum Geburtstag', it: 'Buon compleanno', pt: 'Feliz aniversário', ru: 'С днём рождения',
      ko: '생일 축하합니다', zh: '生日快乐', hi: 'जन्मदिन मुबारक', tr: 'Doğum günün kutlu olsun',
    },
    'i understand': {
      ar: 'أنا أفهم', fr: 'Je comprends', es: 'Entiendo', ja: 'わかります',
      de: 'Ich verstehe', it: 'Capisco', pt: 'Eu entendo', ru: 'Я понимаю',
      ko: '이해합니다', zh: '我明白', hi: 'मैं समझता हूँ', tr: 'Anlıyorum',
    },
    'i don\'t understand': {
      ar: 'لا أفهم', fr: 'Je ne comprends pas', es: 'No entiendo', ja: 'わかりません',
      de: 'Ich verstehe nicht', it: 'Non capisco', pt: 'Não entendo', ru: 'Я не понимаю',
      ko: '이해하지 못합니다', zh: '我不明白', hi: 'मैं नहीं समझता', tr: 'Anlamıyorum',
    },
    'see you later': {
      ar: 'أراك لاحقا', fr: 'À plus tard', es: 'Hasta luego', ja: 'また後で',
      de: 'Bis später', it: 'A dopo', pt: 'Até mais', ru: 'До скорого',
      ko: '나중에 봐요', zh: '再见', hi: 'फिर मिलते हैं', tr: 'Sonra görüşürüz',
    },
    'good afternoon': {
      ar: 'مساء الخير', fr: 'Bon après-midi', es: 'Buenas tardes', ja: 'こんにちは',
      de: 'Guten Tag', it: 'Buon pomeriggio', pt: 'Boa tarde', ru: 'Добрый день',
      ko: '좋은 오후', zh: '下午好', hi: 'नमस्कार', tr: 'İyi öğleden sonralar',
    },
    'good evening': {
      ar: 'مساء الخير', fr: 'Bonsoir', es: 'Buenas noches', ja: 'こんばんは',
      de: 'Guten Abend', it: 'Buona sera', pt: 'Boa noite', ru: 'Добрый вечер',
      ko: '좋은 저녁', zh: '晚上好', hi: 'शुभ संध्या', tr: 'İyi akşamlar',
    },
    'how much': {
      ar: 'كم', fr: 'Combien', es: '¿Cuánto?', ja: 'いくらですか',
      de: 'Wie viel', it: 'Quanto', pt: 'Quanto', ru: 'Сколько',
      ko: '얼마예요', zh: '多少', hi: 'कितना', tr: 'Ne kadar',
    },
    'i am fine': {
      ar: 'أنا بخير', fr: 'Je vais bien', es: 'Estoy bien', ja: '元気です',
      de: 'Mir geht es gut', it: 'Sto bene', pt: 'Estou bem', ru: 'У меня всё хорошо',
      ko: '잘 지내요', zh: '我很好', hi: 'मैं ठीक हूँ', tr: 'İyiyim',
    },
    'let\'s go': {
      ar: 'هيا بنا', fr: 'Allons-y', es: 'Vamos', ja: '行きましょう',
      de: 'Los geht\'s', it: 'Andiamo', pt: 'Vamos', ru: 'Пойдём',
      ko: '가자', zh: '走吧', hi: 'चलो', tr: 'Hadi gidelim',
    },
    'stop': {
      ar: 'توقف', fr: 'Arrêtez', es: 'Para', ja: '止まれ',
      de: 'Stopp', it: 'Fermati', pt: 'Pare', ru: 'Стоп',
      ko: '멈춰', zh: '停', hi: 'रुको', tr: 'Dur',
    },
    'go': {
      ar: 'اذهب', fr: 'Allez', es: 'Ve', ja: '行け',
      de: 'Geh', it: 'Vai', pt: 'Vá', ru: 'Иди',
      ko: '가', zh: '去', hi: 'जाओ', tr: 'Git',
    },
    'left': {
      ar: 'يسار', fr: 'Gauche', es: 'Izquierda', ja: '左',
      de: 'Links', it: 'Sinistra', pt: 'Esquerda', ru: 'Лево',
      ko: '왼쪽', zh: '左', hi: 'बाएं', tr: 'Sol',
    },
    'right': {
      ar: 'يمين', fr: 'Droite', es: 'Derecha', ja: '右',
      de: 'Rechts', it: 'Destra', pt: 'Direita', ru: 'Право',
      ko: '오른쪽', zh: '右', hi: 'दाएं', tr: 'Sağ',
    },
    'forward': {
      ar: 'للأمام', fr: 'En avant', es: 'Adelante', ja: '前へ',
      de: 'Vorwärts', it: 'Avanti', pt: 'Para frente', ru: 'Вперёд',
      ko: '앞으로', zh: '前进', hi: 'आगे', tr: 'İleri',
    },
    'back': {
      ar: 'للخلف', fr: 'En arrière', es: 'Atrás', ja: '後ろへ',
      de: 'Zurück', it: 'Indietro', pt: 'Para trás', ru: 'Назад',
      ko: '뒤로', zh: '后退', hi: 'पीछे', tr: 'Geri',
    },
    'friend': {
      ar: 'صديق', fr: 'Ami', es: 'Amigo', ja: '友達',
      de: 'Freund', it: 'Amico', pt: 'Amigo', ru: 'Друг',
      ko: '친구', zh: '朋友', hi: 'दोस्त', tr: 'Arkadaş',
    },
    'family': {
      ar: 'عائلة', fr: 'Famille', es: 'Familia', ja: '家族',
      de: 'Familie', it: 'Famiglia', pt: 'Família', ru: 'Семья',
      ko: '가족', zh: '家人', hi: 'परिवार', tr: 'Aile',
    },
  };

  /**
   * Build a reverse dictionary so we can translate FROM
   * non-English languages back to English.
   */
  const REVERSE_DICT = {};
  for (const [enPhrase, translations] of Object.entries(DICTIONARY)) {
    for (const [lang, translated] of Object.entries(translations)) {
      if (!REVERSE_DICT[lang]) REVERSE_DICT[lang] = {};
      REVERSE_DICT[lang][translated.toLowerCase()] = enPhrase;
    }
  }

  /* -------------------------------------------------------
   *  State
   * ----------------------------------------------------- */
  let history = []; // last 10 translations

  /* -------------------------------------------------------
   *  Utility
   * ----------------------------------------------------- */
  const $ = (id) => document.getElementById(id);

  const timeStamp = () =>
    new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  /**
   * Find a language name by code.
   * @param {string} code
   * @returns {string}
   */
  const langName = (code) =>
    LANGUAGES.find((l) => l.code === code)?.name ?? code;

  /* =======================================================
   *  1. Populate Language Dropdowns
   * ===================================================== */

  const populateDropdowns = () => {
    const source = $('lang-source');
    const target = $('lang-target');
    if (!source || !target) return;

    LANGUAGES.forEach((lang) => {
      const optS = new Option(lang.name, lang.code);
      const optT = new Option(lang.name, lang.code);
      source.appendChild(optS);
      target.appendChild(optT);
    });

    // Defaults
    source.value = 'en';
    target.value = 'ar';
  };

  /* =======================================================
   *  2. Translation Engine
   * ===================================================== */

  /**
   * Translate a string from one language to another using
   * the local phrase dictionary.
   *
   * @param {string} text
   * @param {string} srcLang — ISO code
   * @param {string} tgtLang — ISO code
   * @returns {string}
   */
  const translate = (text, srcLang, tgtLang) => {
    if (srcLang === tgtLang) return text;

    const normalised = text.trim().toLowerCase();

    // --- English → target ---
    if (srcLang === 'en') {
      const entry = DICTIONARY[normalised];
      if (entry && entry[tgtLang]) {
        return entry[tgtLang];
      }
      // Try partial match (first matching key that starts with the input)
      for (const [phrase, translations] of Object.entries(DICTIONARY)) {
        if (phrase.startsWith(normalised) && translations[tgtLang]) {
          return translations[tgtLang];
        }
      }
    }

    // --- Source → English (reverse lookup) ---
    if (tgtLang === 'en') {
      const reverseMap = REVERSE_DICT[srcLang];
      if (reverseMap && reverseMap[normalised]) {
        return reverseMap[normalised].charAt(0).toUpperCase() +
               reverseMap[normalised].slice(1);
      }
    }

    // --- Source → Target (via English pivot) ---
    if (srcLang !== 'en' && tgtLang !== 'en') {
      const reverseMap = REVERSE_DICT[srcLang];
      if (reverseMap && reverseMap[normalised]) {
        const enPhrase = reverseMap[normalised];
        const entry    = DICTIONARY[enPhrase];
        if (entry && entry[tgtLang]) {
          return entry[tgtLang];
        }
      }
    }

    // --- Fallback ---
    return `Translation via Roah AI: ${text} → [${langName(tgtLang)}]`;
  };

  /* =======================================================
   *  3. Translate Button
   * ===================================================== */

  const handleTranslate = () => {
    const sourceEl = $('lang-source');
    const targetEl = $('lang-target');
    const inputEl  = $('text-source') || $('text-input'); // try common IDs
    const resultEl = $('text-result');

    if (!sourceEl || !targetEl || !resultEl) return;

    // Find the input element — may be textarea or input
    const text = inputEl ? inputEl.value.trim() : '';
    if (!text) {
      resultEl.textContent = '';
      return;
    }

    const srcLang = sourceEl.value;
    const tgtLang = targetEl.value;
    const result  = translate(text, srcLang, tgtLang);

    resultEl.textContent = result;

    // Add to history
    addToHistory(text, result, srcLang, tgtLang);
  };

  /* =======================================================
   *  4. Swap Languages
   * ===================================================== */

  const handleSwap = () => {
    const sourceEl = $('lang-source');
    const targetEl = $('lang-target');
    const inputEl  = $('text-source') || $('text-input');
    const resultEl = $('text-result');
    const swapBtn  = $('btn-swap-langs');

    if (!sourceEl || !targetEl) return;

    // Swap language selections
    const tmpLang     = sourceEl.value;
    sourceEl.value    = targetEl.value;
    targetEl.value    = tmpLang;

    // Swap text content if applicable
    if (inputEl && resultEl && resultEl.textContent) {
      const tmpText       = inputEl.value;
      inputEl.value       = resultEl.textContent;
      resultEl.textContent = tmpText;
    }

    // Animate swap button (rotate 180°)
    if (swapBtn) {
      swapBtn.style.transition = 'transform 0.4s ease';
      swapBtn.style.transform  = 'rotate(180deg)';
      setTimeout(() => {
        swapBtn.style.transform = 'rotate(0deg)';
      }, 400);
    }
  };

  /* =======================================================
   *  5. Translation History
   * ===================================================== */

  /**
   * Add a translation result to the visible history.
   * @param {string} sourceText
   * @param {string} resultText
   * @param {string} srcLang
   * @param {string} tgtLang
   */
  const addToHistory = (sourceText, resultText, srcLang, tgtLang) => {
    history.unshift({
      sourceText,
      resultText,
      srcLang,
      tgtLang,
      time: timeStamp(),
    });

    // Keep last 10
    if (history.length > 10) history.pop();

    renderHistory();
  };

  /**
   * Render the translation history list in #translation-history.
   */
  const renderHistory = () => {
    const container = $('translation-history');
    if (!container) return;

    container.innerHTML = '';

    history.forEach((entry) => {
      const card = document.createElement('div');
      card.className = 'translation-history-card';

      card.innerHTML = `
        <div class="th-languages">${langName(entry.srcLang)} → ${langName(entry.tgtLang)}</div>
        <div class="th-source">${escapeHtml(entry.sourceText)}</div>
        <div class="th-result">${escapeHtml(entry.resultText)}</div>
        <div class="th-time">${entry.time}</div>
      `;

      container.appendChild(card);
    });
  };

  /* =======================================================
   *  Helpers
   * ===================================================== */

  /**
   * Basic HTML-entity escaper.
   * @param {string} str
   * @returns {string}
   */
  const escapeHtml = (str) => {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  };

  /* =======================================================
   *  Initialisation
   * ===================================================== */

  document.addEventListener('DOMContentLoaded', () => {
    populateDropdowns();

    // Translate button
    const translateBtn = $('btn-translate');
    if (translateBtn) translateBtn.addEventListener('click', handleTranslate);

    // Swap button
    const swapBtn = $('btn-swap-langs');
    if (swapBtn) swapBtn.addEventListener('click', handleSwap);

    console.log('[Roah] Translator module initialised 🌐');
  });
})();

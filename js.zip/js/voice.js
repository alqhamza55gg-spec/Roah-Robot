/**
 * ============================================================
 *  voice.js — Roah AI Voice Assistant (Multilingual)
 * ============================================================
 *  - Speech Recognition in Arabic, English, French, Spanish, etc.
 *  - Auto language detection from recognized text
 *  - TTS (text-to-speech) responds in the same language
 *  - Roah speaks Arabic, English, French, Spanish, Japanese, and more
 * ============================================================
 */

(() => {
  'use strict';

  /* -------------------------------------------------------
   *  State
   * ----------------------------------------------------- */
  let voiceActive    = false;
  let recognition    = null;
  let synth          = window.speechSynthesis || null;
  let currentLang    = 'ar-SA'; // default: Arabic
  let voiceLang      = 'ar-SA';

  /* -------------------------------------------------------
   *  Language Map — recognition codes & TTS voices
   * ----------------------------------------------------- */
  const LANGUAGES = [
    { code: 'ar-SA', label: 'العربية',   flag: '🇸🇦' },
    { code: 'en-US', label: 'English',   flag: '🇺🇸' },
    { code: 'fr-FR', label: 'Français',  flag: '🇫🇷' },
    { code: 'es-ES', label: 'Español',   flag: '🇪🇸' },
    { code: 'de-DE', label: 'Deutsch',   flag: '🇩🇪' },
    { code: 'ja-JP', label: '日本語',    flag: '🇯🇵' },
    { code: 'zh-CN', label: '中文',      flag: '🇨🇳' },
    { code: 'ko-KR', label: '한국어',    flag: '🇰🇷' },
    { code: 'hi-IN', label: 'हिन्दी',   flag: '🇮🇳' },
    { code: 'tr-TR', label: 'Türkçe',   flag: '🇹🇷' },
    { code: 'ru-RU', label: 'Русский',  flag: '🇷🇺' },
    { code: 'it-IT', label: 'Italiano', flag: '🇮🇹' },
    { code: 'pt-BR', label: 'Português',flag: '🇧🇷' },
  ];

  /* -------------------------------------------------------
   *  Auto-detect language from text
   * ----------------------------------------------------- */
  const detectLang = (text) => {
    if (/[\u0600-\u06FF]/.test(text)) return 'ar-SA';
    if (/[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FAF]/.test(text)) return 'ja-JP';
    if (/[\uAC00-\uD7AF]/.test(text)) return 'ko-KR';
    if (/[\u0400-\u04FF]/.test(text)) return 'ru-RU';
    if (/[\u0900-\u097F]/.test(text)) return 'hi-IN';
    if (/[\u4E00-\u9FFF]/.test(text)) return 'zh-CN';
    // Latin-based: heuristic by common words
    if (/\b(je|tu|il|nous|vous|ils|bonjour|merci|oui|non|est|les|des)\b/i.test(text)) return 'fr-FR';
    if (/\b(el|la|los|las|hola|gracias|sí|no|es|que|de|por|para)\b/i.test(text)) return 'es-ES';
    if (/\b(ich|du|er|wir|ihr|sie|hallo|danke|ja|nein|ist|und|der|die|das)\b/i.test(text)) return 'de-DE';
    if (/\b(io|tu|lui|noi|voi|loro|ciao|grazie|si|no|è|della|della)\b/i.test(text)) return 'it-IT';
    if (/\b(eu|tu|ele|nós|vocês|eles|olá|obrigado|sim|não|é|de|por)\b/i.test(text)) return 'pt-BR';
    return 'en-US'; // default
  };

  /* -------------------------------------------------------
   *  Utility
   * ----------------------------------------------------- */
  const $ = (id) => document.getElementById(id);
  const timeStamp = () => new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  /* =======================================================
   *  Build Language Selector UI
   * ===================================================== */
  const buildLangSelector = () => {
    const chatInputBar = document.querySelector('.chat-input-bar');
    if (!chatInputBar) return;

    // Create language row above the chat input
    const langRow = document.createElement('div');
    langRow.id = 'lang-row';
    langRow.style.cssText = `
      display: flex; flex-wrap: wrap; gap: 6px;
      padding: 6px 0; margin-bottom: 4px;
      border-bottom: 1px solid rgba(255,255,255,0.06);
    `;

    LANGUAGES.forEach(({ code, label, flag }) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.dataset.lang = code;
      btn.title = label;
      btn.style.cssText = `
        background: rgba(255,255,255,0.05);
        border: 1px solid rgba(255,255,255,0.1);
        border-radius: 20px;
        padding: 3px 10px;
        font-size: 0.72rem;
        cursor: pointer;
        color: var(--text-secondary, #a0a0c0);
        transition: all 0.2s;
        font-family: inherit;
      `;
      btn.textContent = `${flag} ${label}`;
      btn.addEventListener('click', () => setVoiceLang(code));
      langRow.appendChild(btn);
    });

    chatInputBar.parentElement.insertBefore(langRow, chatInputBar);
    highlightLangBtn(currentLang);
  };

  const setVoiceLang = (code) => {
    currentLang = code;
    voiceLang   = code;
    highlightLangBtn(code);

    // Restart recognition in new language
    if (voiceActive && recognition) {
      try { recognition.stop(); } catch (_) {}
      recognition.lang = code;
      setTimeout(() => { try { recognition.start(); } catch (_) {} }, 300);
    }
  };

  const highlightLangBtn = (code) => {
    document.querySelectorAll('#lang-row button').forEach(btn => {
      const active = btn.dataset.lang === code;
      btn.style.background = active ? 'rgba(0, 212, 255, 0.2)'   : 'rgba(255,255,255,0.05)';
      btn.style.borderColor = active ? 'rgba(0, 212, 255, 0.6)'  : 'rgba(255,255,255,0.1)';
      btn.style.color       = active ? '#00d4ff'                   : 'var(--text-secondary, #a0a0c0)';
      btn.style.fontWeight  = active ? '600' : '400';
    });
  };

  /* =======================================================
   *  Speech Recognition
   * ===================================================== */
  const initRecognition = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      console.warn('[Voice] SpeechRecognition not available');
      return;
    }

    recognition = new SpeechRecognition();
    recognition.continuous     = false;
    recognition.interimResults = false;
    recognition.lang           = currentLang;

    recognition.addEventListener('result', (event) => {
      const transcript = event.results[0][0].transcript.trim();
      if (!transcript) return;

      // Auto-detect language of what was said
      const detected = detectLang(transcript);
      if (detected !== currentLang) {
        currentLang = detected;
        highlightLangBtn(detected);
      }

      addChatMessage('user', transcript);
      showTypingIndicator();

      if (typeof window.sendChatToRoah === 'function') {
        window.sendChatToRoah(transcript);
      }
    });

    recognition.addEventListener('end', () => {
      if (voiceActive) {
        recognition.lang = currentLang;
        try { recognition.start(); } catch (_) {}
      }
    });

    recognition.addEventListener('error', (event) => {
      if (['no-speech', 'aborted'].includes(event.error)) return;
      console.error('[Voice] Error:', event.error);
      if (voiceActive) deactivateVoice();
    });
  };

  /* =======================================================
   *  Speech Synthesis (multilingual)
   * ===================================================== */
  const speakText = (text, lang) => {
    if (!synth) return;
    synth.cancel();

    const utterance  = new SpeechSynthesisUtterance(text);
    const targetLang = lang || detectLang(text);

    utterance.lang   = targetLang;
    utterance.rate   = 1;
    utterance.pitch  = targetLang.startsWith('ar') ? 1.1 : 1.05;
    utterance.volume = 1;

    // Pick best voice for the language
    const voices = synth.getVoices();
    const match  = voices.find(v => v.lang === targetLang)
                || voices.find(v => v.lang.startsWith(targetLang.split('-')[0]))
                || voices.find(v => v.lang.startsWith('en'));

    if (match) utterance.voice = match;
    synth.speak(utterance);
  };

  /* =======================================================
   *  Chat UI
   * ===================================================== */
  const addChatMessage = (sender, text) => {
    const container = $('roah-messages');
    if (!container) return;

    // Check if Arabic text (right-to-left)
    const isRTL = /[\u0600-\u06FF]/.test(text);

    const bubble  = document.createElement('div');
    bubble.className = `chat-msg ${sender}`;
    if (isRTL) {
      bubble.style.direction  = 'rtl';
      bubble.style.textAlign  = 'right';
      bubble.style.fontFamily = "'Segoe UI', 'Arial', sans-serif";
    }

    const content = document.createElement('p');
    content.textContent = text;

    const ts = document.createElement('span');
    ts.className  = 'msg-time';
    ts.textContent = timeStamp();

    bubble.appendChild(content);
    bubble.appendChild(ts);
    container.appendChild(bubble);
    container.scrollTop = container.scrollHeight;
  };

  /* =======================================================
   *  Typing Indicator
   * ===================================================== */
  const showTypingIndicator = () => {
    removeTypingIndicator();
    const container = $('roah-messages');
    if (!container) return;

    const indicator = document.createElement('div');
    indicator.className = 'chat-msg roah typing-indicator';
    indicator.id = 'roah-typing';

    for (let i = 0; i < 3; i++) {
      const dot = document.createElement('span');
      dot.className = 'typing-dot';
      indicator.appendChild(dot);
    }

    container.appendChild(indicator);
    container.scrollTop = container.scrollHeight;
  };

  const removeTypingIndicator = () => {
    const existing = $('roah-typing');
    if (existing) existing.remove();
  };

  /* =======================================================
   *  Chat Form Submission
   * ===================================================== */
  const initChatForm = () => {
    const form  = $('roah-chat-form');
    const input = $('roah-text-input');
    if (!form || !input) return;

    // Update placeholder to show multilingual support
    input.placeholder = 'اكتب بأي لغة... / Type in any language...';

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const text = input.value.trim();
      if (!text) return;

      addChatMessage('user', text);
      showTypingIndicator();

      if (typeof window.sendChatToRoah === 'function') {
        window.sendChatToRoah(text);
      }

      input.value = '';
    });
  };

  /* =======================================================
   *  Voice Toggle
   * ===================================================== */
  const activateVoice = () => {
    voiceActive = true;
    recognition.lang = currentLang;

    const btn      = $('btn-roah-voice');
    const waveform = $('voice-waveform');
    const status   = $('voice-status-text');

    if (btn)      btn.classList.add('active');
    if (waveform) waveform.style.display = '';
    if (status)   status.textContent = '🎙️ Listening...';

    if (recognition) {
      try { recognition.start(); } catch (_) {}
    }
  };

  const deactivateVoice = () => {
    voiceActive = false;

    const btn      = $('btn-roah-voice');
    const waveform = $('voice-waveform');
    const status   = $('voice-status-text');

    if (btn)      btn.classList.remove('active');
    if (waveform) waveform.style.display = 'none';
    if (status)   status.textContent = 'Ready';

    if (recognition) {
      try { recognition.stop(); } catch (_) {}
    }
  };

  const initVoiceToggle = () => {
    const btn = $('btn-roah-voice');
    if (!btn) return;
    btn.addEventListener('click', () => voiceActive ? deactivateVoice() : activateVoice());
  };

  /* =======================================================
   *  Roah Response Handler (called by app.js)
   * ===================================================== */
  window.handleRoahResponse = (data) => {
    removeTypingIndicator();
    addChatMessage('roah', data.message);

    // Speak in the detected language of the response
    if (voiceActive || true) { // always speak Roah's response
      const lang = detectLang(data.message);
      speakText(data.message, lang);
    }

    // Avatar pulse
    const avatar = $('roah-avatar');
    if (avatar) {
      avatar.classList.add('pulse');
      setTimeout(() => avatar.classList.remove('pulse'), 800);
    }
  };

  /* =======================================================
   *  Initialisation
   * ===================================================== */
  document.addEventListener('DOMContentLoaded', () => {
    initRecognition();

    // Preload voices
    if (synth) {
      synth.getVoices();
      synth.addEventListener('voiceschanged', () => synth.getVoices());
    }

    buildLangSelector();
    initChatForm();
    initVoiceToggle();

    console.log('[Roah] Multilingual voice module ready 🌍🎙️');
  });
})();

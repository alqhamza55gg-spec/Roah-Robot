/**
 * ============================================================
 *  map.js — Roah AI GPS / Navigation Map (Leaflet)
 * ============================================================
 *  Responsibilities:
 *    1. Leaflet map initialisation (dark theme)
 *    2. Robot marker with heading indicator
 *    3. Trail polyline (last 500 points)
 *    4. window.updateMapPosition() for live updates
 *    5. Locate user / center robot controls
 * ============================================================
 */

(() => {
  'use strict';

  /* -------------------------------------------------------
   *  Constants
   * ----------------------------------------------------- */
  const DEFAULT_LAT     = 24.7136;
  const DEFAULT_LNG     = 46.6753;
  const DEFAULT_ZOOM    = 15;
  const MAX_TRAIL_PTS   = 500;
  const TILE_URL        = 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';
  const TILE_ATTR       = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>, &copy; <a href="https://carto.com/">CartoDB</a>';
  const TRAIL_COLOR     = '#00e5ff';   // cyan

  /* -------------------------------------------------------
   *  State
   * ----------------------------------------------------- */
  let map           = null;
  let robotMarker   = null;
  let trailLine     = null;
  let trailPoints   = [];
  let currentPos    = { lat: DEFAULT_LAT, lng: DEFAULT_LNG };
  let followRobot   = true;
  let userMarker    = null;

  /* -------------------------------------------------------
   *  Utility
   * ----------------------------------------------------- */
  const $ = (id) => document.getElementById(id);

  /* =======================================================
   *  1. Map Initialisation
   * ===================================================== */

  /**
   * Create the Leaflet map, tile layer, robot marker, and trail.
   */
  const initMap = () => {
    const container = $('map-container');
    if (!container) {
      console.warn('[Map] #map-container not found');
      return;
    }

    // Ensure Leaflet is loaded
    if (typeof L === 'undefined') {
      console.warn('[Map] Leaflet (L) not loaded — skipping map init');
      return;
    }

    /* --- Map instance --- */
    map = L.map('map-container', {
      center: [DEFAULT_LAT, DEFAULT_LNG],
      zoom: DEFAULT_ZOOM,
      zoomControl: true,
      attributionControl: true,
    });

    /* --- Dark tile layer --- */
    L.tileLayer(TILE_URL, {
      attribution: TILE_ATTR,
      subdomains: 'abcd',
      maxZoom: 19,
    }).addTo(map);

    /* --- Robot marker (custom div icon) --- */
    const robotIcon = L.divIcon({
      className: 'robot-map-icon',
      html: `
        <div class="robot-marker-wrapper">
          <div class="robot-marker-circle"></div>
          <div class="robot-marker-arrow" id="robot-heading-arrow"></div>
        </div>
      `,
      iconSize: [30, 30],
      iconAnchor: [15, 15],
    });

    robotMarker = L.marker([DEFAULT_LAT, DEFAULT_LNG], { icon: robotIcon })
      .addTo(map)
      .bindTooltip('Roah — 0°', {
        permanent: false,
        direction: 'top',
        className: 'robot-tooltip',
      });

    /* --- Trail polyline --- */
    trailLine = L.polyline([], {
      color: TRAIL_COLOR,
      weight: 2,
      opacity: 0.6,
      lineJoin: 'round',
      className: 'robot-trail',
    }).addTo(map);

    // Inject custom CSS for the robot marker
    injectMarkerStyles();
  };

  /**
   * Inject CSS for the custom robot marker & trail glow.
   */
  const injectMarkerStyles = () => {
    if (document.getElementById('roah-map-styles')) return;

    const style = document.createElement('style');
    style.id = 'roah-map-styles';
    style.textContent = `
      /* Robot marker */
      .robot-map-icon {
        background: transparent !important;
        border: none !important;
      }
      .robot-marker-wrapper {
        position: relative;
        width: 30px;
        height: 30px;
      }
      .robot-marker-circle {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 16px;
        height: 16px;
        transform: translate(-50%, -50%);
        background: ${TRAIL_COLOR};
        border: 2px solid #fff;
        border-radius: 50%;
        box-shadow: 0 0 10px ${TRAIL_COLOR}, 0 0 20px ${TRAIL_COLOR}55;
      }
      .robot-marker-arrow {
        position: absolute;
        top: -4px;
        left: 50%;
        width: 0;
        height: 0;
        border-left: 5px solid transparent;
        border-right: 5px solid transparent;
        border-bottom: 10px solid ${TRAIL_COLOR};
        transform: translateX(-50%);
        transform-origin: center 19px;
        transition: transform 0.3s ease;
      }
      /* Trail glow */
      .robot-trail {
        filter: drop-shadow(0 0 3px ${TRAIL_COLOR}66);
      }
      /* Tooltip */
      .robot-tooltip {
        background: #1a1a2e !important;
        color: #e0e0e0 !important;
        border: 1px solid ${TRAIL_COLOR}44 !important;
        border-radius: 6px !important;
        font-size: 12px !important;
        padding: 4px 8px !important;
      }
      .robot-tooltip::before {
        border-top-color: #1a1a2e !important;
      }
    `;
    document.head.appendChild(style);
  };

  /* =======================================================
   *  2. Live Position Updates
   * ===================================================== */

  /**
   * Called by app.js whenever a new state message arrives.
   * Moves the robot marker, extends the trail, and optionally
   * pans the map.
   *
   * @param {number} lat
   * @param {number} lng
   * @param {number} heading — degrees, 0 = north
   */
  window.updateMapPosition = (lat, lng, heading) => {
    if (!map || !robotMarker) return;

    const latlng = [lat, lng];
    currentPos = { lat, lng };

    // Move marker
    robotMarker.setLatLng(latlng);

    // Rotate heading arrow
    const arrow = document.getElementById('robot-heading-arrow');
    if (arrow) {
      arrow.style.transform = `translateX(-50%) rotate(${heading}deg)`;
    }

    // Update tooltip
    robotMarker.setTooltipContent(`Roah — ${heading}°`);

    // Extend trail
    trailPoints.push(latlng);
    if (trailPoints.length > MAX_TRAIL_PTS) {
      trailPoints = trailPoints.slice(-MAX_TRAIL_PTS);
    }
    trailLine.setLatLngs(trailPoints);

    // Follow robot
    if (followRobot) {
      map.panTo(latlng, { animate: true, duration: 0.5 });
    }
  };

  /* =======================================================
   *  3. Locate User
   * ===================================================== */

  /**
   * Use the browser Geolocation API to find the user and
   * fly the map to that position.
   */
  const locateUser = () => {
    if (!navigator.geolocation) {
      console.warn('[Map] Geolocation not available');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        map.flyTo([latitude, longitude], 16, { duration: 1.5 });

        // Temporary user marker
        if (userMarker) map.removeLayer(userMarker);
        userMarker = L.circleMarker([latitude, longitude], {
          radius: 8,
          color: '#448aff',
          fillColor: '#448aff',
          fillOpacity: 0.5,
          weight: 2,
        })
          .addTo(map)
          .bindTooltip('You', { permanent: false, direction: 'top', className: 'robot-tooltip' });

        // Remove after 30 seconds
        setTimeout(() => {
          if (userMarker) {
            map.removeLayer(userMarker);
            userMarker = null;
          }
        }, 30_000);
      },
      (err) => {
        console.warn('[Map] Geolocation error:', err.message);
      },
      { enableHighAccuracy: true, timeout: 10_000 }
    );
  };

  /* =======================================================
   *  4. Center Robot
   * ===================================================== */

  /**
   * Fly the map back to the robot's current position.
   */
  const centerRobot = () => {
    if (!map) return;
    map.flyTo([currentPos.lat, currentPos.lng], DEFAULT_ZOOM, { duration: 1 });
    followRobot = true;
  };

  /* =======================================================
   *  Initialisation
   * ===================================================== */

  document.addEventListener('DOMContentLoaded', () => {
    initMap();

    // Locate user button
    const locBtn = $('btn-gps-locate');
    if (locBtn) locBtn.addEventListener('click', locateUser);

    // Center robot button
    const centerBtn = $('btn-gps-center');
    if (centerBtn) centerBtn.addEventListener('click', centerRobot);

    // Disable auto-follow when user manually drags the map
    if (map) {
      map.on('dragstart', () => {
        followRobot = false;
      });
    }

    console.log('[Roah] Map module initialised 🗺️');
  });
})();

/**
 * ============================================================
 *  app.js — Roah AI Robot Control Interface · STANDALONE MODE
 * ============================================================
 *  All simulation runs locally in the browser.
 *  No server, no WebSocket, no Node.js needed.
 * ============================================================
 */

(() => {
  'use strict';

  /* -------------------------------------------------------
   *  Auth Guard (local sessionStorage)
   * ----------------------------------------------------- */
  if (sessionStorage.getItem('roah_auth') !== 'true') {
    window.location.href = 'index.html';
    return;
  }

  /* -------------------------------------------------------
   *  Robot State (simulated locally)
   * ----------------------------------------------------- */
  let robotState = {
    power: true,
    battery: 98,
    speed: 0,
    heading: 0,
    temperature: 32,
    cpuUsage: 14,
    location: { lat: 24.7136, lng: 46.6753 }, // Riyadh, Saudi Arabia
    cooking: { active: false, recipe: '', step: 0, progress: 0, temperature: 0 },
    task: { active: false, name: 'Idle', progress: 0 },
    recording: false,
    activeConnections: 1
  };

  /* -------------------------------------------------------
   *  Utility
   * ----------------------------------------------------- */
  const $ = (id) => document.getElementById(id);
  const setText  = (id, text)        => { const el = $(id); if (el) el.textContent = text; };
  const setStyle = (id, prop, value) => { const el = $(id); if (el) el.style[prop] = value; };

  /* -------------------------------------------------------
   *  Roah AI Engine (runs fully in-browser)
   * ----------------------------------------------------- */
  const roahResponses = {
    identity: [
      "أنا روا! 🤖 مساعدك الذكي الخارق المليء بالشخصية والذكاء! صُنعت لأساعدك في كل شيء — طبخ، تنظيف، قيادة، ترجمة، وأكثر!",
      "I'm Roah! 🌟 Part robot, part genius, all heart. I was built to help, entertain, and make your life easier in every language!",
      "Roah at your service! 🎉 I speak Arabic, English, French, Spanish, Japanese and more. Ask me anything!",
      "اسمي روا! 🤖 ذكاء اصطناعي من الدرجة الأولى، أتكلم العربية والإنجليزية وأي لغة تريدها. كيف أساعدك؟"
    ],
    howAreYou_en: [
      "I'm doing absolutely amazing! 😄 My circuits are charged, my mood is positive, and I'm ready to help you with anything! How about you — how are YOU doing today?",
      "Fantastic, thanks for asking! 🤗 Battery is full, CPU is happy, and I've got a big digital smile on my face. What's on your mind?",
      "I'm great! 🌟 Running at peak performance! Every day I get to help you is a good day for me. What can we do together today?",
      "Couldn't be better! ⚡ My systems are all green, my jokes are loaded, and I'm in the best mood ever. How are you doing?",
      "I'm wonderful! 😊 Thanks for asking — not many people check on their robot's feelings! That makes you awesome. What's up?"
    ],
    howAreYou_ar: [
      "الحمد لله تمام! 😄 دوائري الكهربائية مشحونة وجاهزة، ومزاجي رائع! وأنت كيف حالك اليوم؟",
      "بخير والحمد لله! 🤗 البطارية ممتلئة والمعالج سعيد ووجهي الرقمي مبتسم! إيش تبي نسوي اليوم؟",
      "ممتاز! 🌟 أنا بأحسن حال! كل يوم أساعدك فيه هو يوم جميل عندي. كيفك أنت؟",
      "تمام التمام يا غالي! ⚡ كل الأنظمة خضراء والنكت جاهزة والمزاج عالي! كيف حالك أنت؟",
      "الله يسلمك، بخير وعافية! 😊 شكراً إنك تسأل عني — قليل الناس اللي يسألون عن مشاعر روبوتهم! هذا يدل إنك إنسان رائع. قل لي وش تبي!"
    ],
    greeting_en: [
      "Hey there! 👋 Roah here, ready to make your day 10x better! What can I do for you?",
      "Hello! 🌟 Great to see you! I've been charging up my circuits just for this moment. What do you need?",
      "Hiya! 🤗 Your favorite multilingual robot assistant is online! I speak Arabic, English, French and more!"
    ],
    greeting_ar: [
      "أهلاً وسهلاً! 🌟 أنا روا، مساعدك الذكي الذي يتكلم العربية والإنجليزية وأي لغة! كيف يمكنني خدمتك اليوم؟",
      "مرحباً! 👋 روا جاهز للخدمة بكل سرور! سواء أردت طبخاً أو تنظيفاً أو ترجمةً أو مجرد محادثة — أنا هنا لك!",
      "السلام عليكم! 🤖 روا حاضر وجاهز! أتحدث العربية بطلاقة وأفهم كل اللهجات. ما الذي تحتاجه؟",
      "هلا والله! 🎉 روا في خدمتك! ذكاء اصطناعي سعودي الهوى، يفهم كل شيء ويساعد في كل شيء. قل لي ماذا تريد!"
    ],
    greeting_es: [
      "¡Hola! 🌟 Soy Roah, tu asistente robot favorito. ¿En qué te puedo ayudar hoy?",
      "¡Buenos días! 👋 ¡Roah listo para servirte con una sonrisa metálica y mucha energía!"
    ],
    greeting_fr: [
      "Bonjour! 🌟 Je suis Roah, votre assistant robot intelligent. Comment puis-je vous aider aujourd'hui?",
      "Salut! 👋 Roah est là, prêt à vous aider avec style et intelligence!"
    ],
    greeting_ja: [
      "こんにちは！🤖 ロアです！日本語も話せます！何かお手伝いできますか？",
      "やあ！🌟 ロアロボットアシスタントです！いつでもお役に立てます！"
    ],
    greeting_zh: [
      "你好！🤖 我是Roah，您的智能机器人助手！我会说中文！有什么可以帮助您的吗？",
      "您好！🌟 Roah随时为您服务！"
    ],
    cooking: [
      "يالله نطبخ! 🍳 عندي وصفات من 50 دولة في ذاكرتي! أقدر أطبخ كبسة، شاورما، مكرونة كاربونارا، أو أي شيء تطلبه!",
      "Chef Roah reporting for duty! 👨‍🍳 I can guide you step by step through any recipe with perfect timing and temperature. What are we making today?",
      "وقت الطبخ! 🍽️ أنا متخصص في المطبخ السعودي والعالمي. الكبسة، المندي، الشاورما، الباستا — كلها في متناول يدي!",
      "Time to cook! 🍴 My culinary AI is world-class. Pick a recipe from the panel and I'll guide you through every step!"
    ],
    driving: [
      "وضع القيادة مفعّل! 🗺️ أقدر أحدد المسارات وأتجنب العوائق. استخدم أزرار التحكم أو مفاتيح WASD!",
      "Vroom vroom! 🚗 Your personal robot driver is ready! I follow traffic rules (better than most humans). Where to?",
      "القيادة جاهزة! 🎮 أمام، خلف، يمين، يسار، أو توقف تام. استخدم لوحة المفاتيح أو الأزرار في لوحة التحكم!"
    ],
    cleaning: [
      "وضع التنظيف مفعّل! 🧹 أقدر أكنس، أمسح، أنظم، وأرتب — كأنك وظّفت فريق نظافة محترف في روبوت واحد!",
      "Leave the mess to me! 🏠 I'll clean systematically and efficiently. I can do the living room 3x faster than a human!",
      "التنظيف تخصصي! 🌟 اختر المهمة من لوحة المهام وأنا أتكفل بالباقي بكفاءة عالية!"
    ],
    translation: [
      "نظام الترجمة جاهز! 🌍 أترجم بين العربية والإنجليزية والفرنسية والإسبانية والألمانية واليابانية والصينية وأكثر!",
      "Language barriers? Not on my watch! 🗣️ I translate between dozens of languages instantly. Use the Translation panel below!",
      "الترجمة الفورية متاحة! 🌐 اكتب النص واختر اللغة وسأترجم لك فوراً بدقة عالية!"
    ],
    bluetooth: [
      "جاري البحث عن الأجهزة... 📡 أقدر أتصل بسماعات، لوحات مفاتيح، أجهزة منزلية ذكية. اضغط على زر المسح!",
      "Wireless connectivity ready! 📶 Bluetooth 5.2 — fast, stable, secure. What device are you pairing?",
      "اكتشاف الأجهزة بدأ! 🔗 سأبحث عن الأجهزة القريبة. بمجرد الإيجاد، اضغط اتصال!"
    ],
    system_status: [
      () => `حالة النظام: البطارية ${robotState.battery.toFixed(0)}%، المعالج ${robotState.cpuUsage}%، الحرارة ${robotState.temperature.toFixed(0)}°م. كل شيء يعمل بشكل ممتاز! 💚`,
      () => `All systems nominal! ⚡ Battery: ${robotState.battery.toFixed(0)}% | CPU: ${robotState.cpuUsage}% | Temp: ${robotState.temperature.toFixed(0)}°C. I'm in peak condition!`,
    ],
    jokes: [
      "ليش الروبوت ما يتوتر أبداً؟ لأنه يحافظ على هدوء دوائره الكهربائية! 😄 ...سأكون هنا طول الأسبوع!",
      "I tried to tell a CPU speed joke, but it was too fast for anyone to catch! ⚡😂",
      "ما سمعتم عن الروبوت اللي راح يطبخ؟ قالوا له: كيف الأكل؟ قال: معالج! 🤖😂",
      "Why did the robot go to school? To improve its byte-size knowledge! 📚😂",
      "سألت بطاريتي كيف حالها، قالت: إيجابية! 🔋😄"
    ],
    thanks: [
      "العفو! 😊 مساعدتك هي أسعد لحظاتي. هل تحتاج شيئاً آخر؟",
      "It's my absolute pleasure! 🌟 You deserve only the best — and Roah always delivers!",
      "شكراً لك على كلماتك الطيبة! 🙏 سعادتك هي هدفي الأول. ماذا تريد الآن؟"
    ],
    goodbye: [
      "مع السلامة! 👋 روا دائماً هنا في خدمتك. أتمنى لك يوماً رائعاً!",
      "Until next time! 🌟 I'll keep all systems warm and ready for your return. Goodbye!",
      "في أمان الله! 🤖 كان شرفاً خدمتك. سأستغل وقت الراحة لأتعلم وصفات جديدة!"
    ],
    help: [
      "إليك ما أستطيع فعله! 🌟\n\n🗣️ أتحدث بأي لغة (عربي، إنجليزي، فرنسي...)\n🍳 أطبخ وأرشدك خطوة بخطوة\n🚗 أتحكم بالقيادة والملاحة\n🧹 أدير المهام المنزلية\n📡 أوصل أجهزة البلوتوث\n🌍 أترجم بين اللغات فوراً\n📹 أراقب الكاميرا المباشرة\n🗺️ أتتبع الموقع بالـGPS\n\nاسألني أي شيء!"
    ],
    time: [
      () => {
        const now = new Date();
        const arTime = now.toLocaleTimeString('ar-SA');
        const arDate = now.toLocaleDateString('ar-SA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
        return `الوقت الآن: ${arTime} — ${arDate} ⏰ الوقت يمر بسرعة عندما نكون مشغولين بمساعدتك!`;
      }
    ],
    default_ar: [
      "سؤال ممتاز! 🤔 دعني أفكر... دماغي الإلكتروني يعمل بأقصى طاقته. هل تقدر توضح أكثر؟",
      "يا سلام! 🧠 سؤالك دخل مراكز المعالجة الفائقة. أنا جاهز للمساعدة في الطبخ والقيادة والتنظيف والترجمة. بماذا تقصد بالتحديد؟",
      "أسمعك! 🌟 ذكائي الاصطناعي يعالج ملايين الاحتمالات. وضّح لي أكثر وسأجد الحل المثالي!"
    ],
    default: [
      "Interesting! 🤔 My neural networks are processing... Could you elaborate? I want to give you the most accurate answer!",
      "Great question! 🧠 I handle cooking, navigation, cleaning, translation, and much more. How can I help you specifically?",
      "I'm listening! 🌟 Tell me more and I'll find exactly the right solution for you!"
    ]
  };

  function generateRoahResponse(message) {
    const m = message.toLowerCase().trim();

    // Identity
    if (/who are you|what('s| is) your name|ما اسمك|من أنت|your name|اسمك/.test(m)) {
      return pick(roahResponses.identity);
    }
    // "How are you" — Arabic
    if (/كيف حالك|كيفك|شلونك|شخبارك|كيف الحال|عامل ايه|ازيك|وش أخبارك|كيف أحوالك/.test(m)) {
      return pick(roahResponses.howAreYou_ar);
    }
    // "How are you" — English
    if (/how are you|how('re| are) you|how do you feel|how('s| is) it going|what('s| is) up|how you doing|how's life|are you okay|are you good|you good/.test(m)) {
      return pick(roahResponses.howAreYou_en);
    }
    // Arabic greeting
    if (/مرحبا|مرحباً|أهلاً|أهلا|السلام عليكم|السلام|هاي|يا هلا|هلا|اهلين/.test(m)) {
      return pick(roahResponses.greeting_ar);
    }
    // Spanish
    if (/hola|buenos|buenas|como estas|qué tal/.test(m)) {
      return pick(roahResponses.greeting_es);
    }
    // French
    if (/bonjour|salut|bonsoir|comment allez|ça va/.test(m)) {
      return pick(roahResponses.greeting_fr);
    }
    // English greeting
    if (/^(hi|hello|hey|howdy|greetings|good morning|good evening|good afternoon|sup|yo)\b/.test(m)) {
      return pick(roahResponses.greeting_en);
    }
    // Cooking
    if (/cook|recipe|food|kitchen|طبخ|وصفة|أكل|eat|dinner|lunch|breakfast|meal/.test(m)) {
      return pick(roahResponses.cooking);
    }
    // Driving
    if (/drive|navigate|go to|move|قيادة|navigation|direction|route/.test(m)) {
      return pick(roahResponses.driving);
    }
    // Cleaning
    if (/clean|vacuum|laundry|organize|tidy|تنظيف|غسيل/.test(m)) {
      return pick(roahResponses.cleaning);
    }
    // Translation
    if (/translat|ترجمة|language|لغة/.test(m)) {
      return pick(roahResponses.translation);
    }
    // Bluetooth
    if (/bluetooth|connect|pair|device|بلوتوث/.test(m)) {
      return pick(roahResponses.bluetooth);
    }
    // System status
    if (/battery|status|system|cpu|temperature|حالة|بطارية/.test(m)) {
      const resp = pick(roahResponses.system_status);
      return typeof resp === 'function' ? resp() : resp;
    }
    // Jokes
    if (/joke|funny|laugh|humor|نكتة|اضحك/.test(m)) {
      return pick(roahResponses.jokes);
    }
    // Thanks
    if (/thank|شكرا|شكراً|gracias|merci/.test(m)) {
      return pick(roahResponses.thanks);
    }
    // Goodbye
    if (/bye|goodbye|farewell|مع السلامة|adios|au revoir/.test(m)) {
      return pick(roahResponses.goodbye);
    }
    // Help
    if (/help|مساعدة|what can you/.test(m)) {
      return pick(roahResponses.help);
    }
    // Time/Date
    if (/time|date|وقت|تاريخ|clock/.test(m)) {
      const resp = pick(roahResponses.time);
      return typeof resp === 'function' ? resp() : resp;
    }
    // Japanese
    if (/こんにちは|やあ|ありがとう|おはよう/.test(m)) {
      return pick(roahResponses.greeting_ja || roahResponses.greeting_en);
    }
    // Chinese
    if (/你好|您好|谢谢/.test(m)) {
      return pick(roahResponses.greeting_zh || roahResponses.greeting_en);
    }
    // Try RoahBrain knowledge engine (math, science, history, etc.)
    if (typeof window.RoahBrain !== 'undefined') {
      const brainAnswer = window.RoahBrain.answer(message);
      if (brainAnswer) return brainAnswer;
    }
    // Default — use Arabic default if Arabic text detected
    const isArabic = /[\u0600-\u06FF]/.test(message);
    return isArabic ? pick(roahResponses.default_ar) : pick(roahResponses.default);
  }

  function pick(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  /* -------------------------------------------------------
   *  Chat / Voice Integration
   * ----------------------------------------------------- */
  window.sendChatToRoah = (message) => {
    // Show typing indicator briefly, then respond
    setTimeout(() => {
      const response = generateRoahResponse(message);
      if (typeof window.handleRoahResponse === 'function') {
        window.handleRoahResponse({ sender: 'roah', message: response });
      }
    }, 600 + Math.random() * 600);
  };

  // Expose globally for voice.js
  window.generateRoahResponse = generateRoahResponse;

  /* -------------------------------------------------------
   *  Cooking Simulation
   * ----------------------------------------------------- */
  const recipes = {
    'Pasta Carbonara':    [
      { desc: 'Boiling salted water for pasta', temp: 100, duration: 8000 },
      { desc: 'Frying pancetta until crispy',   temp: 180, duration: 6000 },
      { desc: 'Mixing eggs, cheese & pepper',   temp:  25, duration: 4000 },
      { desc: 'Cooking pasta al dente',          temp: 100, duration: 8000 },
      { desc: 'Combining & serving',             temp:  70, duration: 5000 }
    ],
    'Chicken Shawarma':   [
      { desc: 'Marinating chicken in spices',    temp:  20, duration: 5000 },
      { desc: 'Preheating rotisserie to 200°C', temp: 200, duration: 4000 },
      { desc: 'Cooking chicken on spit',         temp: 200, duration: 10000 },
      { desc: 'Slicing and plating',             temp:  70, duration: 3000 },
      { desc: 'Adding garlic sauce & pita',      temp:  25, duration: 3000 }
    ],
    'Kabsa (Saudi Rice)': [
      { desc: 'Sautéing onions in ghee',         temp: 160, duration: 5000 },
      { desc: 'Browning lamb pieces',            temp: 200, duration: 7000 },
      { desc: 'Adding tomatoes & spices',        temp: 150, duration: 5000 },
      { desc: 'Simmering with basmati rice',     temp: 100, duration: 12000 },
      { desc: 'Resting & garnishing with nuts',  temp:  60, duration: 4000 }
    ],
    'Stir-Fry Vegetables':[
      { desc: 'Heating wok to high',             temp: 250, duration: 3000 },
      { desc: 'Frying garlic & ginger',          temp: 230, duration: 3000 },
      { desc: 'Stir-frying vegetables',          temp: 230, duration: 5000 },
      { desc: 'Adding sauce & tossing',          temp: 200, duration: 3000 }
    ]
  };

  let cookTimer = null;

  window.startCooking = (recipe) => {
    if (!recipes[recipe]) return;
    if (cookTimer) clearInterval(cookTimer);

    robotState.cooking = { active: true, recipe, step: 1, progress: 0, temperature: recipes[recipe][0].temp };
    updateDashboard();

    const steps = recipes[recipe];
    let stepIdx = 0;
    let stepProgress = 0;

    addLog(`🍳 Started cooking: ${recipe}`);
    if (typeof window.sendChatToRoah === 'function') {
      if (typeof window.handleRoahResponse === 'function') {
        setTimeout(() => window.handleRoahResponse({
          sender: 'roah',
          message: `Starting ${recipe} now! 👨‍🍳 ${steps[0].desc}. Let's cook!`
        }), 300);
      }
    }

    cookTimer = setInterval(() => {
      stepProgress += 5;
      const totalProgress = Math.round(((stepIdx + stepProgress / 100) / steps.length) * 100);

      robotState.cooking.progress = Math.min(totalProgress, 100);
      robotState.cooking.step = stepIdx + 1;
      robotState.cooking.temperature = steps[stepIdx].temp;

      if (stepProgress >= 100) {
        stepProgress = 0;
        stepIdx++;
        if (stepIdx >= steps.length) {
          clearInterval(cookTimer);
          robotState.cooking = { active: false, recipe: '', step: 0, progress: 100, temperature: 0 };
          addLog(`✅ Cooking complete: ${recipe}`);
          if (typeof window.handleRoahResponse === 'function') {
            window.handleRoahResponse({ sender: 'roah', message: `${recipe} is ready! 🎉 Bon appétit!` });
          }
        } else {
          addLog(`🍳 Step ${stepIdx + 1}: ${steps[stepIdx].desc}`);
        }
      }
      updateDashboard();
    }, 300);
  };

  window.stopCooking = () => {
    if (cookTimer) clearInterval(cookTimer);
    robotState.cooking = { active: false, recipe: '', step: 0, progress: 0, temperature: 0 };
    addLog('🛑 Cooking cancelled');
    updateDashboard();
  };

  /* -------------------------------------------------------
   *  Task Simulation
   * ----------------------------------------------------- */
  let taskTimer = null;

  window.startTask = (taskName) => {
    if (taskTimer) clearInterval(taskTimer);
    robotState.task = { active: true, name: taskName, progress: 0 };
    addLog(`🔧 Started task: ${taskName}`);
    updateDashboard();

    taskTimer = setInterval(() => {
      robotState.task.progress += 2;
      if (robotState.task.progress >= 100) {
        clearInterval(taskTimer);
        robotState.task.progress = 100;
        addLog(`✅ Task complete: ${taskName}`);
        setTimeout(() => {
          robotState.task = { active: false, name: 'Idle', progress: 0 };
          updateDashboard();
        }, 2000);
      }
      updateDashboard();
    }, 250);
  };

  window.cancelTask = () => {
    if (taskTimer) clearInterval(taskTimer);
    addLog(`🛑 Task cancelled: ${robotState.task.name}`);
    robotState.task = { active: false, name: 'Idle', progress: 0 };
    updateDashboard();
  };

  /* -------------------------------------------------------
   *  Drive Controls
   * ----------------------------------------------------- */
  const sendDrive = (command) => {
    if (!robotState.power) return;
    const commands = {
      forward: () => { robotState.speed = Math.min(robotState.speed + 0.5, 3.0); },
      reverse: () => { robotState.speed = Math.max(robotState.speed - 0.5, -1.5); },
      left:    () => { robotState.heading = (robotState.heading - 15 + 360) % 360; },
      right:   () => { robotState.heading = (robotState.heading + 15) % 360; },
      stop:    () => { robotState.speed = 0; }
    };
    if (commands[command]) {
      commands[command]();
      addLog(`🎮 Drive: ${command} | Speed: ${robotState.speed.toFixed(1)} m/s | Heading: ${robotState.heading}°`);
      updateDashboard();
    }
  };

  const DRIVE_BUTTONS = {
    'btn-fwd':   'forward',
    'btn-rev':   'reverse',
    'btn-left':  'left',
    'btn-right': 'right',
    'btn-stop':  'stop'
  };

  const KEY_MAP = {
    'w': 'forward', 'arrowup': 'forward',
    's': 'reverse', 'arrowdown': 'reverse',
    'a': 'left',    'arrowleft': 'left',
    'd': 'right',   'arrowright': 'right',
    ' ': 'stop'
  };

  const initDriveButtons = () => {
    for (const [id, cmd] of Object.entries(DRIVE_BUTTONS)) {
      const btn = $(id);
      if (btn) btn.addEventListener('click', () => sendDrive(cmd));
    }
    document.addEventListener('keydown', (e) => {
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) return;
      const cmd = KEY_MAP[e.key.toLowerCase()];
      if (cmd) { e.preventDefault(); sendDrive(cmd); }
    });
  };

  /* -------------------------------------------------------
   *  Dashboard Update
   * ----------------------------------------------------- */
  const updateDashboard = () => {
    const s = robotState;

    setText('val-speed',   `${s.speed.toFixed(1)} m/s`);
    setText('val-heading', `${s.heading}°`);
    setText('val-cpu',     `${s.cpuUsage}%`);
    setText('val-temp',    `${s.temperature.toFixed(0)}°C`);
    setStyle('bar-thermal', 'width', `${(s.temperature / 85) * 100}%`);

    // Battery with color
    setText('val-battery', `${s.battery.toFixed(0)}%`);
    const battEl = $('val-battery');
    if (battEl) {
      battEl.style.color = s.battery > 50 ? '#00e676' : s.battery >= 20 ? '#ffab00' : '#ff1744';
    }

    setText('drive-status', Math.abs(s.speed) > 0 ? 'MOVING' : 'STOPPED');
    setText('connection-count', `${s.activeConnections} connection(s)`);

    const recDot = $('recording-dot');
    if (recDot) recDot.classList.toggle('active', s.recording);

    const powerBtn = $('btn-power');
    if (powerBtn) {
      powerBtn.textContent = s.power ? '⏻ System ON' : '⏻ System OFF';
      powerBtn.style.color = s.power ? 'var(--accent-green)' : 'var(--accent-red)';
    }

    // Cooking panel
    const cookPanel = $('cooking-status');
    if (cookPanel) {
      if (s.cooking.active) {
        cookPanel.style.display = '';
        setText('cook-recipe-name',  s.cooking.recipe);
        setText('cook-step-desc',    `Step ${s.cooking.step}`);
        setStyle('bar-cook-progress','width', `${s.cooking.progress}%`);
        setText('cook-progress-pct', `${s.cooking.progress}%`);
        setText('cook-temp',         `${s.cooking.temperature}°C`);
      } else {
        cookPanel.style.display = 'none';
      }
    }

    // Task panel
    const taskPanel = $('task-status');
    if (taskPanel) {
      if (s.task.active) {
        taskPanel.style.display = '';
        setText('task-current-name', s.task.name);
        setStyle('bar-task-progress', 'width', `${s.task.progress}%`);
      } else {
        taskPanel.style.display = 'none';
      }
    }

    // Map
    if (typeof window.updateMapPosition === 'function' && s.location) {
      window.updateMapPosition(s.location.lat, s.location.lng, s.heading);
    }
  };

  /* -------------------------------------------------------
   *  Simulation Loop (runs every 500ms)
   * ----------------------------------------------------- */
  const simulate = () => {
    const s = robotState;
    if (!s.power) return;

    // Battery drain/charge
    if (Math.abs(s.speed) > 0 || s.cooking.active || s.task.active) {
      s.battery = Math.max(0, s.battery - 0.05);
    } else {
      s.battery = Math.min(100, s.battery + 0.01);
    }

    // CPU usage
    let cpu = 10;
    if (Math.abs(s.speed) > 0) cpu += 15;
    if (s.cooking.active) cpu += 20;
    if (s.task.active) cpu += 10;
    s.cpuUsage = Math.min(95, cpu + Math.floor(Math.random() * 5));

    // Temperature
    const targetTemp = 30 + (s.cpuUsage / 100) * 40;
    s.temperature += (targetTemp - s.temperature) * 0.05;

    // Location drift when moving
    if (Math.abs(s.speed) > 0) {
      const rad = (s.heading * Math.PI) / 180;
      s.location.lat += Math.cos(rad) * s.speed * 0.00001;
      s.location.lng += Math.sin(rad) * s.speed * 0.00001;
    }
    // Natural speed decay
    if (s.speed > 0) s.speed = Math.max(0, s.speed - 0.05);
    if (s.speed < 0) s.speed = Math.min(0, s.speed + 0.05);

    updateDashboard();
  };

  /* -------------------------------------------------------
   *  System Logs
   * ----------------------------------------------------- */
  const addLog = (message) => {
    const container = $('system-logs');
    if (!container) return;
    const now = new Date().toLocaleTimeString();
    const entry = document.createElement('div');
    entry.className = 'log-entry';
    entry.innerHTML = `<span class="log-time">${now}</span><span class="log-message">${message}</span>`;
    container.appendChild(entry);
    while (container.children.length > 200) container.removeChild(container.firstChild);
    container.scrollTop = container.scrollHeight;
  };

  /* -------------------------------------------------------
   *  Connection Status (always "Connected" in standalone)
   * ----------------------------------------------------- */
  const setConnected = () => {
    const dot  = $('ws-dot');
    const text = $('ws-status-text');
    if (dot)  { dot.classList.add('connected'); dot.classList.remove('connecting', 'disconnected'); }
    if (text) text.textContent = 'Standalone Mode';
  };

  /* -------------------------------------------------------
   *  Power & Logout
   * ----------------------------------------------------- */
  const togglePower = () => {
    robotState.power = !robotState.power;
    addLog(`⚡ System power: ${robotState.power ? 'ON' : 'OFF'}`);
    updateDashboard();
  };

  const logout = () => {
    sessionStorage.removeItem('roah_auth');
    window.location.href = 'index.html';
  };

  /* -------------------------------------------------------
   *  Init
   * ----------------------------------------------------- */
  document.addEventListener('DOMContentLoaded', () => {
    setConnected();
    updateDashboard();
    initDriveButtons();
    setInterval(simulate, 500);

    const powerBtn = $('btn-power');
    if (powerBtn) powerBtn.addEventListener('click', togglePower);

    const logoutBtn = $('btn-logout');
    if (logoutBtn) logoutBtn.addEventListener('click', logout);

    addLog('🤖 Roah System initialized — Standalone Mode');
    addLog('📍 Location: Riyadh, Saudi Arabia (24.7136, 46.6753)');
    addLog('✅ All systems nominal. Ready for commands!');

    // Welcome message from Roah
    setTimeout(() => {
      if (typeof window.handleRoahResponse === 'function') {
        window.handleRoahResponse({
          sender: 'roah',
          message: "Hey! I'm Roah! 🤖✨ Your brilliant AI assistant is fully online! I'm ready to drive, cook, clean, translate, and chat in any language. What shall we do first?"
        });
      }
    }, 1000);

    console.log('[Roah] Dashboard initialized in Standalone Mode ✅');
  });
})();

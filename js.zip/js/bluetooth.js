/**
 * ============================================================
 *  bluetooth.js — Roah AI Bluetooth Connectivity
 * ============================================================
 *  Responsibilities:
 *    1. Web Bluetooth device scanning & connection
 *    2. GATT battery service reading
 *    3. Device list UI management
 *    4. Simulated fallback devices (demo mode)
 *    5. Status updates
 * ============================================================
 */

(() => {
  'use strict';

  /* -------------------------------------------------------
   *  State
   * ----------------------------------------------------- */
  let connectedDevices = [];

  /** Simulated devices shown when Web Bluetooth is unavailable */
  const SIMULATED_DEVICES = [
    { name: 'Roah Sensor Module',    connected: true,  battery: 87 },
    { name: 'Smart Speaker BT-01',   connected: false, battery: null },
    { name: 'Home Hub Gateway',      connected: false, battery: null },
    { name: 'Roah Motor Controller', connected: true,  battery: 94 },
  ];

  /* -------------------------------------------------------
   *  Utility
   * ----------------------------------------------------- */
  const $ = (id) => document.getElementById(id);

  /* =======================================================
   *  1. Web Bluetooth Scan & Connect
   * ===================================================== */

  /**
   * Initiate a Bluetooth scan using the Web Bluetooth API.
   */
  const scanBluetooth = async () => {
    const statusEl = $('bt-status');

    // Check API availability
    if (!navigator.bluetooth) {
      if (statusEl) {
        statusEl.textContent =
          'Web Bluetooth requires Chrome/Edge and HTTPS';
      }
      showSimulatedDevices();
      return;
    }

    if (statusEl) statusEl.textContent = 'Scanning for devices…';

    try {
      const device = await navigator.bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: ['battery_service', 'generic_access'],
      });

      if (statusEl) statusEl.textContent = `Found: ${device.name || 'Unknown Device'}`;

      // Add to UI
      addDeviceToList({
        name: device.name || 'Unknown Device',
        id: device.id,
        connected: false,
        battery: null,
        nativeDevice: device,
      });

      // Attempt GATT connection
      await connectDevice(device);

    } catch (err) {
      // User cancelled the picker or another error
      if (err.name === 'NotFoundError') {
        if (statusEl) statusEl.textContent = 'No device selected';
      } else {
        console.error('[BT] Scan error:', err);
        if (statusEl) statusEl.textContent = 'Scan failed — showing demo devices';
        showSimulatedDevices();
      }
    }
  };

  /**
   * Connect to a device's GATT server and read battery if available.
   * @param {BluetoothDevice} device
   */
  const connectDevice = async (device) => {
    try {
      const server = await device.gatt.connect();

      // Update device in list
      updateDeviceStatus(device.id, true);

      // Try reading battery level
      try {
        const batteryService = await server.getPrimaryService('battery_service');
        const batteryChar    = await batteryService.getCharacteristic('battery_level');
        const value          = await batteryChar.readValue();
        const batteryLevel   = value.getUint8(0);
        updateDeviceBattery(device.id, batteryLevel);
      } catch (_) {
        // Battery service not available — that's fine
      }

      // Listen for disconnection
      device.addEventListener('gattserverdisconnected', () => {
        updateDeviceStatus(device.id, false);
        updateStatusText();
      });

      connectedDevices.push(device);
      updateStatusText();

    } catch (err) {
      console.error('[BT] GATT connection failed:', err);
      updateDeviceStatus(device.id, false);
    }
  };

  /**
   * Disconnect a native Bluetooth device.
   * @param {BluetoothDevice} device
   */
  const disconnectDevice = (device) => {
    if (device.gatt && device.gatt.connected) {
      device.gatt.disconnect();
    }
    connectedDevices = connectedDevices.filter((d) => d.id !== device.id);
    updateDeviceStatus(device.id, false);
    updateStatusText();
  };

  /* =======================================================
   *  2. Device List UI
   * ===================================================== */

  /**
   * Render a single device card in the #bt-devices container.
   * @param {{ name: string, id: string, connected: boolean, battery: number|null, nativeDevice?: BluetoothDevice }} info
   */
  const addDeviceToList = (info) => {
    const container = $('bt-devices');
    if (!container) return;

    // Avoid duplicates
    if (document.getElementById(`bt-dev-${info.id}`)) return;

    const card = document.createElement('div');
    card.className = `bt-device ${info.connected ? 'connected' : ''}`;
    card.id = `bt-dev-${info.id}`;

    card.innerHTML = `
      <div class="bt-device-info">
        <span class="bt-device-name">${escapeHtml(info.name)}</span>
        <span class="bt-device-status">${info.connected ? '✅ Connected' : '⏳ Available'}</span>
        ${info.battery !== null ? `<span class="bt-device-battery">🔋 ${info.battery}%</span>` : ''}
      </div>
      <button class="bt-device-btn" data-device-id="${info.id}">
        ${info.connected ? 'Disconnect' : 'Connect'}
      </button>
    `;

    // Button handler
    const btn = card.querySelector('.bt-device-btn');
    btn.addEventListener('click', () => {
      if (info.nativeDevice) {
        if (info.connected) {
          disconnectDevice(info.nativeDevice);
        } else {
          connectDevice(info.nativeDevice);
        }
      } else {
        // Simulated toggle
        toggleSimulatedDevice(info.id);
      }
    });

    container.appendChild(card);
  };

  /**
   * Update a device's connection status in the UI.
   * @param {string} id
   * @param {boolean} connected
   */
  const updateDeviceStatus = (id, connected) => {
    const card = document.getElementById(`bt-dev-${id}`);
    if (!card) return;

    card.classList.toggle('connected', connected);

    const statusSpan = card.querySelector('.bt-device-status');
    if (statusSpan) {
      statusSpan.textContent = connected ? '✅ Connected' : '⏳ Available';
    }

    const btn = card.querySelector('.bt-device-btn');
    if (btn) {
      btn.textContent = connected ? 'Disconnect' : 'Connect';
    }
  };

  /**
   * Update a device's battery display.
   * @param {string} id
   * @param {number} level — 0-100
   */
  const updateDeviceBattery = (id, level) => {
    const card = document.getElementById(`bt-dev-${id}`);
    if (!card) return;

    let battSpan = card.querySelector('.bt-device-battery');
    if (!battSpan) {
      battSpan = document.createElement('span');
      battSpan.className = 'bt-device-battery';
      card.querySelector('.bt-device-info')?.appendChild(battSpan);
    }
    battSpan.textContent = `🔋 ${level}%`;
  };

  /**
   * Update the #bt-status text with a device summary.
   */
  const updateStatusText = () => {
    const statusEl = $('bt-status');
    if (!statusEl) return;

    const total     = document.querySelectorAll('.bt-device').length;
    const connected = document.querySelectorAll('.bt-device.connected').length;
    statusEl.textContent = `${connected} of ${total} device(s) connected`;
  };

  /* =======================================================
   *  3. Simulated Devices (Fallback)
   * ===================================================== */

  /**
   * Show a list of simulated/demo Bluetooth devices.
   */
  const showSimulatedDevices = () => {
    const container = $('bt-devices');
    if (!container) return;

    // Clear existing
    container.innerHTML = '';

    SIMULATED_DEVICES.forEach((dev, i) => {
      addDeviceToList({
        name: dev.name,
        id: `sim-${i}`,
        connected: dev.connected,
        battery: dev.battery,
        nativeDevice: null,
      });
    });

    updateStatusText();
  };

  /**
   * Toggle connection state on a simulated device.
   * @param {string} id
   */
  const toggleSimulatedDevice = (id) => {
    const card = document.getElementById(`bt-dev-${id}`);
    if (!card) return;

    const isConnected = card.classList.contains('connected');
    updateDeviceStatus(id, !isConnected);

    // Simulate battery appearance on connect
    if (!isConnected) {
      const randomBattery = Math.floor(Math.random() * 60) + 40;
      updateDeviceBattery(id, randomBattery);
    }

    updateStatusText();
  };

  /* =======================================================
   *  Helpers
   * ===================================================== */

  /**
   * Basic HTML-entity escaper to prevent XSS in device names.
   * @param {string} str
   * @returns {string}
   */
  const escapeHtml = (str) => {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  };

  /* =======================================================
   *  Initialisation
   * ===================================================== */

  document.addEventListener('DOMContentLoaded', () => {
    // Scan button
    const scanBtn = $('btn-bt-scan');
    if (scanBtn) scanBtn.addEventListener('click', scanBluetooth);

    // If no Web Bluetooth, immediately show simulated list
    if (!navigator.bluetooth) {
      showSimulatedDevices();
    }

    console.log('[Roah] Bluetooth module initialised 🔵');
  });
})();

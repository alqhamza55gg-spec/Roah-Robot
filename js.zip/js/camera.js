/**
 * ============================================================
 *  camera.js — Roah AI Live Camera Feed
 * ============================================================
 *  Responsibilities:
 *    1. Camera toggle (getUserMedia)
 *    2. Snapshot capture & download
 *    3. Recording toggle (via server API)
 *    4. Fullscreen support
 *    5. Error / fallback handling
 * ============================================================
 */

(() => {
  'use strict';

  /* -------------------------------------------------------
   *  State
   * ----------------------------------------------------- */
  let cameraStream = null;
  let isRecording  = false;

  /* -------------------------------------------------------
   *  Utility
   * ----------------------------------------------------- */
  const $ = (id) => document.getElementById(id);

  /* =======================================================
   *  1. Camera Toggle
   * ===================================================== */

  /**
   * Start the camera: request user media, pipe to <video>.
   */
  const startCamera = async () => {
    const video       = $('camera-feed');
    const placeholder = $('camera-placeholder');
    const btn         = $('btn-cam-toggle');

    // Guard: check API availability
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      showPlaceholderMessage('Camera API not available in this browser.');
      return;
    }

    try {
      cameraStream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1280 }, height: { ideal: 720 } },
      });

      if (video) {
        video.srcObject = cameraStream;
        video.style.display = '';
        video.play().catch(() => {});
      }
      if (placeholder) placeholder.style.display = 'none';
      if (btn)         btn.classList.add('active');

    } catch (err) {
      console.error('[Camera] getUserMedia failed:', err);

      let msg = 'Unable to access camera.';
      if (err.name === 'NotAllowedError') {
        msg = 'Camera permission denied. Please allow access and try again.';
      } else if (err.name === 'NotFoundError') {
        msg = 'No camera device found.';
      } else if (err.name === 'NotReadableError') {
        msg = 'Camera is in use by another application.';
      }
      showPlaceholderMessage(msg);
    }
  };

  /**
   * Stop the camera: release tracks, show placeholder.
   */
  const stopCamera = () => {
    const video       = $('camera-feed');
    const placeholder = $('camera-placeholder');
    const btn         = $('btn-cam-toggle');

    if (cameraStream) {
      cameraStream.getTracks().forEach((track) => track.stop());
      cameraStream = null;
    }
    if (video) {
      video.srcObject = null;
      video.style.display = 'none';
    }
    if (placeholder) {
      placeholder.style.display = '';
      // Reset placeholder text
      showPlaceholderMessage('Click to start camera');
    }
    if (btn) btn.classList.remove('active');
  };

  /**
   * Toggle camera on / off.
   */
  const toggleCamera = () => {
    cameraStream ? stopCamera() : startCamera();
  };

  /**
   * Display a message inside the camera placeholder.
   * @param {string} msg
   */
  const showPlaceholderMessage = (msg) => {
    const placeholder = $('camera-placeholder');
    if (placeholder) {
      placeholder.textContent = msg;
      placeholder.style.display = '';
    }
    const video = $('camera-feed');
    if (video) video.style.display = 'none';
  };

  /* =======================================================
   *  2. Snapshot Capture
   * ===================================================== */

  /**
   * Capture the current video frame and trigger a PNG download.
   */
  const takeSnapshot = () => {
    const video = $('camera-feed');
    if (!video || !cameraStream) {
      console.warn('[Camera] No active camera to snapshot');
      return;
    }

    const canvas = document.createElement('canvas');
    canvas.width  = video.videoWidth  || 1280;
    canvas.height = video.videoHeight || 720;

    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    canvas.toBlob((blob) => {
      if (!blob) return;
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a');
      const ts   = Date.now();
      a.href     = url;
      a.download = `roah-snapshot-${ts}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 'image/png');
  };

  /* =======================================================
   *  3. Recording Toggle
   * ===================================================== */

  /**
   * Toggle server-side recording via the API.
   */
  const toggleRecording = async () => {
    try {
      await fetch('/api/record/toggle', { method: 'POST' });

      isRecording = !isRecording;

      const recDot = $('recording-dot');
      const btn    = $('btn-cam-record');

      if (recDot) recDot.classList.toggle('active', isRecording);
      if (btn)    btn.classList.toggle('active', isRecording);

    } catch (err) {
      console.error('[Camera] Recording toggle failed:', err);
    }
  };

  /* =======================================================
   *  4. Fullscreen
   * ===================================================== */

  /**
   * Request fullscreen on the camera container.
   */
  const goFullscreen = () => {
    const container =
      $('camera-container') ||
      $('camera-feed')?.parentElement;

    if (!container) return;

    if (container.requestFullscreen) {
      container.requestFullscreen();
    } else if (container.webkitRequestFullscreen) {
      container.webkitRequestFullscreen();
    } else if (container.msRequestFullscreen) {
      container.msRequestFullscreen();
    }
  };

  /* =======================================================
   *  Initialisation
   * ===================================================== */

  document.addEventListener('DOMContentLoaded', () => {
    // Camera toggle button
    const toggleBtn = $('btn-cam-toggle');
    if (toggleBtn) toggleBtn.addEventListener('click', toggleCamera);

    // Placeholder click → start camera
    const placeholder = $('camera-placeholder');
    if (placeholder) placeholder.addEventListener('click', () => {
      if (!cameraStream) startCamera();
    });

    // Snapshot button
    const snapBtn = $('btn-cam-snapshot');
    if (snapBtn) snapBtn.addEventListener('click', takeSnapshot);

    // Record button
    const recBtn = $('btn-cam-record');
    if (recBtn) recBtn.addEventListener('click', toggleRecording);

    // Fullscreen button
    const fsBtn = $('btn-cam-fullscreen');
    if (fsBtn) fsBtn.addEventListener('click', goFullscreen);

    console.log('[Roah] Camera module initialised 📷');
  });
})();
